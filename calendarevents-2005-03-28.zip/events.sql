# MySQL-Front Dump 2.5
#
# Host: localhost   Database: ugcart
# --------------------------------------------------------
# Server version 4.0.15


#
# Table structure for table 'events'
#

DROP TABLE IF EXISTS events;
CREATE TABLE events (
  eventID bigint(20) unsigned NOT NULL auto_increment,
  eventDate date default NULL,
  eventContent longtext,
  langCode varchar(20) default 'en',
  PRIMARY KEY  (eventID)
) TYPE=MyISAM;



#
# Dumping data for table 'events'
#

INSERT INTO events (eventID, eventDate, eventContent, langCode) VALUES("1", "2005-03-23", "this is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first eventthis is my first event", "en");
INSERT INTO events (eventID, eventDate, eventContent, langCode) VALUES("2", "2005-03-30", "this is my second event", "en");
INSERT INTO events (eventID, eventDate, eventContent, langCode) VALUES("3", "2005-03-30", "&#2351;&#2361; &#2350;&#2375;&#2352;&#2366; &#2346;&#2361;&#2354;&#2366; &#2360;&#2306;&#2342;&#2375;&#2358; &#2361;&#2376;", "hi");
INSERT INTO events (eventID, eventDate, eventContent, langCode) VALUES("4", "2005-03-29", "This is new event", "en");
INSERT INTO events (eventID, eventDate, eventContent, langCode) VALUES("5", "2005-03-29", "This is new event", "en");
INSERT INTO events (eventID, eventDate, eventContent, langCode) VALUES("6", "2005-03-29", "This is new event", "en");
INSERT INTO events (eventID, eventDate, eventContent, langCode) VALUES("7", "2005-04-15", "This is new event", "en");
INSERT INTO events (eventID, eventDate, eventContent, langCode) VALUES("8", "2005-04-15", "This is new event", "en");
INSERT INTO events (eventID, eventDate, eventContent, langCode) VALUES("9", "2005-04-17", "This is updated third event", "en");
