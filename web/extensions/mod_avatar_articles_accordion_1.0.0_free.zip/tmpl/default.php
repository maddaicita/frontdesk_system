<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_articles_news
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$document->addStyleSheet('modules/mod_avatar_articles_accordion/assets/css/default.css');
$document->addScript('http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js');
$document->addScript('modules/mod_avatar_articles_accordion/assets/js/jquery.easyAccordion.js');
$rand = uniqid('avatar-articles-accordion');

?>
<script type="text/javascript">
	jQuery.noConflict();
	(function($){
		$(function(){
			$(document).ready(function(){
				$('#<?php echo $rand; ?>').easyAccordion({
					autoStart: <?php echo $autoStart; ?>, 
					slideInterval: <?php echo $duration; ?>,
					slideNum:true	
				}); 
			});
		});
	})(jQuery);
</script>
<div id="<?php echo $rand; ?>" class="avatar-article-accordion <?php echo $moduleclassSfx; ?>">
	<dl>
		<?php foreach ($list as $k => $item): ?>
			<dt>
				<?php 
					if ($params->get('item_title')) 
					{
						$title = '<'.$params->get('item_heading'). ' class="item-title">';
						$title .= $item->title;
						
						$title .= '</'.$params->get('item_heading').'>';
					}
					echo $title;
				?>
			</dt>
			<dd>
				<?php
					echo $title;
					
					if (!$params->get('intro_only')) {
						echo $item->afterDisplayTitle;
					}
					
					echo '<div class="item-short-intro">'. strip_tags($item->introtext). '</div>';
					echo '<div style="clear:both;"></div>';
					echo '<a class="read-more" href="'.$item->link.'" target="_blank">'.(($params->get('readmore') != '') ? $params->get('readmore') : $item->linkText).'</a>';
				?>
			</dd>	
		<?php endforeach; ?>
	</dl>
</div>

<div class="avatar-article-news-copyright" style="display: <?php echo ($copyright) ? '': 'none'; ?>">
	&copy; JoomAvatar.com
	<a target="_blank" href="http://joomavatar.com" title="Joomla Template & Extension">Joomla Extension</a>-
	<a target="_blank" href="http://joomavatar.com" title="Joomla Template & Extension">Joomla Template</a>
</div>


	



