<?php
/**
 * @version		$Id: mod_AvatarK2ArticlePro.php 48 2011-06-25 08:22:19Z trung3388@gmail.com $
 * @copyright	JoomAvatar.com
 * @author		Tran Nam Chung
 * @mail		chungnt@joomavatar.com
 * @link		http://joomavatar.com
 * @license		License GNU General Public License version 2 or later
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
// Include the syndicate functions only once
$language = JFactory::getLanguage();
$language->load('mod_k2.j16', JPATH_ADMINISTRATOR, null, true);
require_once( dirname(__FILE__).DIRECTORY_SEPARATOR.'helper.php' );
$componentParams = JComponentHelper::getParams('com_k2');
$items = modavatark2slideitemsHelper::getItems($params);

if (count($items)<1)return;

$sliderWidth = modavatark2slideitemsHelper::getsliderWidth($params);
$cr = modavatark2slideitemsHelper::getcr($params);
$slices = modavatark2slideitemsHelper::getslices($params);
$boxRows = modavatark2slideitemsHelper::getboxRows($params);
$boxCols = $boxRows*2;
$animSpeed = modavatark2slideitemsHelper::getanimSpeed($params);
$pauseTime = modavatark2slideitemsHelper::getpauseTime($params);
$effect = modavatark2slideitemsHelper::geteffect($params);
$theme = "default";
$controlNav = modavatark2slideitemsHelper::getcontrolNav($params);
$randomStart = modavatark2slideitemsHelper::getrandomStart($params);
$titleColor = modavatark2slideitemsHelper::gettitleColor($params);
$introColor = modavatark2slideitemsHelper::getintroColor($params);
require( JModuleHelper::getLayoutPath( 'mod_avatark2slideitems' ) );
?>