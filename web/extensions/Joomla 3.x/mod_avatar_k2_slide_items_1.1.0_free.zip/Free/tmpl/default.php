<?php // no direct access
/**
 * @version		$Id: mod_avatarK2slideitems.php 48 2011-06-25 08:22:19Z trung3388@gmail.com $
 * @copyright	JoomAvatar.com
 * @author		Tran Nam Chung
 * @mail		chungnt@joomavatar.com
 * @link		http://joomavatar.com
 * @license		License GNU General Public License version 2 or later
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
$document = JFactory::getDocument();
$document->addStyleSheet("modules/mod_avatark2slideitems/assets/css/$theme.css");
$document->addStyleSheet("modules/mod_avatark2slideitems/assets/css/nivo-slider.css");
$document->addScript("modules/mod_avatark2slideitems/assets/js/jquery.nivo.slider.js");
$id = "free";
$count = 0;	
?>
<div id="avatar_k2_slide_items_<?php echo $id?>" class="slider-wrapper theme-<?php echo $theme;?>" style="width:<?php echo $sliderWidth;?>;height:auto;">
    <div id="slider_<?php echo $id;?>" class="nivoSlider">
        <?php foreach ($items as $key=>$item):	?>
		<a href="<?php echo $item->link;?>" title="<?php echo $item->title;?>">
			<img src="<?php if(strlen($item->image) == 1) echo JURI::base().'/modules/mod_avatark2slideitems/assets/images/blank.jpg'; else echo $item->image;?>" alt="<?php echo $item->link;?>" title="<?php echo $item->title;?><br/><?php echo strip_tags($item->introtext);?>">
		</a>
		<?php $count++; if($count == 2) break;?>
		<?php endforeach;?>
    </div>
</div>		
<script type="text/javascript">
jQuery.noConflict();
(function($) 
{ 
	$(function() 
	{
		$(document).ready( function()
		{					
			$('#slider_<?php echo $id;?>').nivoSlider({
				effect			:'<?php if(sizeof($effect) > 0)
								{
									for($n = 0; $n < sizeof($effect)-1; $n++)
										{echo ($effect[$n]);echo ",";}
									echo ($effect[$n]);
								}
								else echo $effect;?>',
				slices			:<?php echo $slices;?>,
				boxRows			:<?php echo $boxRows;?>,
				boxCols			:<?php echo $boxCols;?>,
				animSpeed		:<?php echo $animSpeed;?>,
				pauseTime		:<?php echo $pauseTime;?>,
				controlNav		:<?php echo $controlNav;?>,
				randomStart		:<?php echo $randomStart;?>,
			});
			$('#slider_<?php echo $id;?> .nivo-caption a').css("color","<?php echo $titleColor;?>");
			$('#slider_<?php echo $id;?> .nivo-caption p').css("color","<?php echo $introColor;?>");
		});
	})
})(jQuery);
</script>
<div class="avatar-copyright" style="width:100%;margin: 5px;text-align: center;">
	&copy; JoomAvatar.com
	<a target="_blank" href="http://joomavatar.com" title="Joomla Template & Extension">Joomla Extension</a>-
	<a target="_blank" href="http://joomavatar.com" title="Joomla Template & Extension">Joomla Template</a>
</div>