<?php
############################################################################
#
# colors for the calendar views 

# background color
# $bgcolor = '#FFFFF0';		// page background color

# two colors for alternating rows
$catcolor = '#F0F4F0'; 
$secondcatcolor = '#FFF8FF'; 

$overlibbgclr = '#F4F4F4'; 	// bgcolor for overlib window 

$dayview_w = '100%' ; 		// width for day view 
$weekview_w = '100%' ;		// width for week view 
$catview_w = '100%' ;		// width for category view

$unapprovedclr = '#FFC0C0' ;  // background color for unapproved events in administrator calendar 

############################################################################

?>
