<?php
############################################################################
#
# colors for the calendar views 

# background color
# $bgcolor = '#E5EC1C';		// page background color

# two colors for alternating rows
$catcolor = '#F2FF19'; 
$secondcatcolor = '#EEFF88'; 

$overlibbgclr = '#F2B6EF'; 	// bgcolor for overlib window 

$dayview_w = '100%' ; 		// width for day view 
$weekview_w = '100%' ;		// width for week view 
$catview_w = '100%' ;		// width for category view

$unapprovedclr = '#CCFF44' ;  // background color for unapproved events in administrator calendar 

############################################################################

?>
