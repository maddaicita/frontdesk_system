<?php
$mth[1]="Januari";
$mth[2]="Februari";
$mth[3]="Maret";
$mth[4]="April";
$mth[5]="Mei";
$mth[6]="Juni";
$mth[7]="Juli";
$mth[8]="Agustus";
$mth[9]="September";
$mth[10]="Oktober";
$mth[11]="November";
$mth[12]="Desember";
?>