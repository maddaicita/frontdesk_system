<?php 
$mth[1]="Januari";  // changed JOA 05.03.2006 
$mth[2]="Februari";  // changed JOA 05.03.2006 
$mth[3]="Maart"; 
$mth[4]="April"; 
$mth[5]="Mei"; 
$mth[6]="Juni"; 
$mth[7]="Juli"; 
$mth[8]="Augustus"; 
$mth[9]="September"; 
$mth[10]="October"; 
$mth[11]="November"; 
$mth[12]="December"; 
?>
