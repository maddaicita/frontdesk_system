
/* --- menu items --- */
var MENU_ITEMS = [
		
	['Termine','#',{'sb' :'Events'},
	['Hinzuf&uuml;gen','cal_event.php?op=eventform',{'sb' :'Add'}],
	['Best&auml;tigungen','calendar.php?op=approval',{'sb' :'Approvals'}],
	['VergangeneTermine','cal_history.php?op=hist',{'sb' :'Historical Items'}]],
	['Anschauen','#',{'sb' :'View'},
	['Kategorien','cal_cat.php?op=cats',{'sb' :'Categories'}],
	['Aktueller Monat','calendar.php?op=cal',{'sb' :'Current Month'}],
	['Aktuelle Woche','cal_adminweek.php?op=week',{'sb' :'Current Week'}],
	['Heute','cal_adminday.php?op=day',{'sb' :'Today'}],
	['Benutzer','cal_user.php?op=users',{'sb' :'Users'}]],
	['Benutzer-Kalender','../calendar.php',{'sb' :'User Calendar'}],
	['Logout','cal_login.php?op=logout',{'sb' :'Logout'}]
];
	