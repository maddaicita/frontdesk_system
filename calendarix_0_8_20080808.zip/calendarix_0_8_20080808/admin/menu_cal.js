
var MENU_POS = [
		
{
	// Vertical Offset between adjacent levels in pixels
	'block_top'  : 6,
	// Horizontal Offset between adjacent levels in pixels
	'block_left' : 8,
	
	'top': 0,
	'left': 119,
	// Item's width in pixels
	'width'      : 120,
	// Item's height in pixels
	'height'     : 20,
	// Time Delay in milliseconds before subling block expands  
	// after mouse pointer overs an item
	'expd_delay' : 100,
	'hide_delay' : 100,
	'css' : {
		'inner' : ['mainouti', 'mainoveri', 'maindowni'],
		'outer' : ['mainouto', 'mainovero', 'maindowno']
	}
},
{
	// Vertical Offset between adjacent levels in pixels
	'block_top'  : 21,
	// Horizontal Offset between adjacent levels in pixels
	'block_left' : 0,
	
	'top': 20,
	'left': 0,
	// Item's height in pixels
	'height'     : 21,
	'css' : {
		'inner' : ['sub1outi', 'sub1overi', 'sub1downi'],
		'outer' : ['sub1outo', 'sub1overo', 'sub1downo']
	}
}	
];
	