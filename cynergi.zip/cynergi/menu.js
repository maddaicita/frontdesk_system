﻿stm_bm(["menu4096",820,"","blank.gif",0,"","",0,0,250,0,1000,1,0,0,"","",0,0,1,2,"default","hand",""],this);
stm_bp("p0",[0,4,0,0,1,1,15,0,100,"",-2,"",-2,50,0,0,"#799BD8","transparent","",3,0,0,"#000000","",-1,-1,0,"transparent","",0,"",-1,-1,0,"transparent","",0,"",-1,-1,0,"transparent","",0,"",-1,-1,0,"transparent","",0,"","","","",0,0,0,0,0,0,0,0]);
stm_ai("p0i0",[0,"Home             ","","",-1,-1,0,"menu.php","_self","","","icon_01a.gif","icon_01a.gif",15,15,0,"","",0,0,0,0,1,"#FFFFF7",0,"#FFFFF7",0,"","",2,2,1,1,"#999999","#999999","#666666","#666666","bold 10pt Verdana","bold 10pt Verdana",0,0],18,28);
stm_aix("p0i1","p0i0",[0,"Tennant search","","",-1,-1,0,"search_tennant.php","_self","","","icon_01a.gif","icon_01a.gif",15,15,0,"","",0,0,0,0,1,"#FFFFF7",0,"#FFFFF7",0,"","",3,3],154,28);
stm_aix("p0i2","p0i1",[0,"Phone search","","",-1,-1,0,"search_phone.php"],155,28);
stm_aix("p0i3","p0i1",[0,"Unit search","","",-1,-1,0,"search_unit.php"],155,28);
stm_aix("p0i4","p0i1",[0,"Update password","","",-1,-1,0,"update_pass.php"],155,28);
stm_ep();
stm_em();
