-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 30, 2014 at 12:07 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `cynergi`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_admins`
-- 

CREATE TABLE `tbl_admins` (
  `id_admin` tinyint(3) NOT NULL auto_increment,
  `username` varchar(20) collate utf8_unicode_ci NOT NULL,
  `names` varchar(40) collate utf8_unicode_ci NOT NULL,
  `password` varchar(32) collate utf8_unicode_ci NOT NULL,
  `creator` tinyint(2) NOT NULL,
  PRIMARY KEY  (`id_admin`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Adminstrators table' AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `tbl_admins`
-- 

INSERT INTO `tbl_admins` VALUES (3, 'lleon', 'Luis Leon', '0aa2126a289e0613c35fa885703dae32', 1);
INSERT INTO `tbl_admins` VALUES (4, 'hgutierrez', 'Hector Gutierrez', 'c3b03df348c1d9260c2ce0ab6c7a1527', 1);
INSERT INTO `tbl_admins` VALUES (5, 'junior', 'Junior', '426067cd17edc095a7094b10ac4647d9', 0);
INSERT INTO `tbl_admins` VALUES (10, 'abarrios', 'Alex Barrios', 'df8564be275cb52e6facc34916fae32f', 0);
INSERT INTO `tbl_admins` VALUES (11, 'jurekmg1980', 'Jurek Martinez', '96e556130c3faf00fe12a87b45fed3aa', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_config`
-- 

CREATE TABLE `tbl_config` (
  `id_config` tinyint(1) NOT NULL,
  `comport` varchar(5) collate utf8_unicode_ci NOT NULL,
  `closewindows` tinyint(2) NOT NULL,
  PRIMARY KEY  (`id_config`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Setting table';

-- 
-- Dumping data for table `tbl_config`
-- 

INSERT INTO `tbl_config` VALUES (1, 'COM3', 7);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_log_search`
-- 

CREATE TABLE `tbl_log_search` (
  `id_log` mediumint(9) NOT NULL auto_increment,
  `date` varchar(19) collate utf8_unicode_ci NOT NULL,
  `ip` varchar(15) collate utf8_unicode_ci NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  `data_logged` varchar(40) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id_log`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Logs table' AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `tbl_log_search`
-- 

INSERT INTO `tbl_log_search` VALUES (1, '07/30/2014-9:09:14', '127.0.0.1', 3, '201');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_msgs`
-- 

CREATE TABLE `tbl_msgs` (
  `id_msgs` mediumint(8) NOT NULL auto_increment,
  `id_usuario` tinyint(2) NOT NULL,
  `msgs_date` varchar(19) collate utf8_unicode_ci NOT NULL,
  `msgs_text` text collate utf8_unicode_ci NOT NULL,
  `msgs_dateb` varchar(19) collate utf8_unicode_ci default NULL,
  `msgs_ans` text collate utf8_unicode_ci,
  `read` int(1) NOT NULL default '0',
  `id_admin` tinyint(2) NOT NULL,
  PRIMARY KEY  (`id_msgs`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='messages table' AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `tbl_msgs`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_tenant_phones`
-- 

CREATE TABLE `tbl_tenant_phones` (
  `id_phone` mediumint(8) NOT NULL,
  `id_tenant` smallint(6) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `phone` varchar(10) collate utf8_unicode_ci NOT NULL,
  `extension` varchar(5) collate utf8_unicode_ci default NULL,
  `id_admin` tinyint(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='table of phone numbers';

-- 
-- Dumping data for table `tbl_tenant_phones`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_tennants`
-- 

CREATE TABLE `tbl_tennants` (
  `id_tennant` smallint(6) NOT NULL auto_increment,
  `code` varchar(10) collate utf8_unicode_ci default NULL,
  `bldg` varchar(4) collate utf8_unicode_ci default NULL,
  `address` varchar(40) collate utf8_unicode_ci default NULL,
  `apt` varchar(4) collate utf8_unicode_ci NOT NULL,
  `names` varchar(60) collate utf8_unicode_ci NOT NULL,
  `phones` varchar(60) collate utf8_unicode_ci NOT NULL,
  `email` varchar(60) collate utf8_unicode_ci NOT NULL COMMENT 'email',
  `make1` varchar(20) collate utf8_unicode_ci default NULL,
  `model1` varchar(20) collate utf8_unicode_ci default NULL,
  `tag1` varchar(10) collate utf8_unicode_ci default NULL,
  `make2` varchar(20) collate utf8_unicode_ci default NULL,
  `model2` varchar(20) collate utf8_unicode_ci default NULL,
  `tag2` varchar(10) collate utf8_unicode_ci default NULL,
  `comments` varchar(255) collate utf8_unicode_ci default NULL,
  `picture` longblob,
  `id_admin` tinyint(2) NOT NULL,
  PRIMARY KEY  (`id_tennant`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='dplace tennats table' AUTO_INCREMENT=333 ;

-- 
-- Dumping data for table `tbl_tennants`
-- 

INSERT INTO `tbl_tennants` VALUES (4, NULL, NULL, NULL, '205', 'Ada Margarita Balcarcer', '305-467-6908', 'abartinc@hotmail.com', 'MINI/COOPER', NULL, 'FL-982XLP', NULL, NULL, NULL, 'Text her If possible, if see doesn''t answer.', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (8, NULL, NULL, NULL, '211', 'Mario Bailey', '1205-246-3932', 'mariobailey@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (9, NULL, NULL, NULL, '212', 'Mara Degenhardt', '786-205-0068', 'maramd2@me.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (218, NULL, NULL, NULL, '201', 'Alberto Gayoso Gonzalo', '13059783695', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (241, NULL, NULL, NULL, '607', 'Vincent John', '19178324501', '', NULL, NULL, NULL, NULL, NULL, NULL, '13522165223', NULL, 3);
INSERT INTO `tbl_tennants` VALUES (246, NULL, NULL, NULL, '310', 'Gloria Campilis', '17863034656', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (27, NULL, NULL, NULL, '410', 'Mario Rochebois', '305-776-9676', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (30, NULL, NULL, NULL, '502', 'Realliving Hotel', '17864594571', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (31, NULL, NULL, NULL, '503', 'Louis Jay Studio', '305-794-0421', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (45, NULL, NULL, NULL, '608', 'Raimundo Ruga', '305-733-3155', '', 'BMW/ X5', NULL, 'FL-937TYP', NULL, NULL, NULL, '	', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (326, NULL, NULL, NULL, '811', 'Robert Zemnickis', '13052187830', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (56, NULL, NULL, NULL, '801', 'Robin Schwartz', '305-794-1864', '', 'AUDI', 'A8', 'BLACK', NULL, NULL, NULL, 'DECAL# 119', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (58, NULL, NULL, NULL, '803', 'David Solero', '13058570350', '', 'IZUZU', '4X4', '490TAA', NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (61, NULL, NULL, NULL, '807', 'Cubillas Teofilo', '305-967-3512', '', 'MAZDA/6', NULL, 'FL-X603EI', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (64, NULL, NULL, NULL, '810', 'Mathieu Romana', '1347-417-2667', '', 'VOLKWAGON', 'GOLF', 'FL-U/K', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (243, NULL, NULL, NULL, '603', 'Dimitri Baile', '17862539594', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (73, NULL, NULL, NULL, '401', 'Odet Atala (After hrs & emergency only)', '7863396518', 'odet@realmiamigroup.com', NULL, NULL, NULL, NULL, NULL, NULL, 'Please call Real Inc Lcc \r\nMon-Fri\r\n\r\nAT NIGHT PLEASE CALL ONCE, IF YOU CAN TEXT HER ', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (76, NULL, NULL, NULL, '805', 'Sheldon Harris', '1914-774-2249', '', 'BMW', NULL, 'FL-N249QL', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (78, NULL, NULL, NULL, '208', 'wellmeaning office, Pablo Maida, Fabiana', '3055739045', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (81, NULL, NULL, NULL, 'P01', 'Kookie Maffett', '7865431621', 'kookiemaffett26@gmail.com', 'Nissan 2013', 'altima', 'BAW-7342', NULL, NULL, NULL, 'New Car Paper Tag\r\n', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (83, NULL, NULL, NULL, 'P07', 'Maria Cecilia Romer', '14072279781', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (84, NULL, NULL, NULL, 'P06', 'Maldonado Zhar', '3052155105', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (87, NULL, NULL, NULL, 'p03', 'Eduardo Peleaz', '17865100370', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (88, NULL, NULL, NULL, 'p03', 'Eduardo''s Hotel', '7864594571', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (97, NULL, NULL, NULL, '309', 'Gary Ibanez', '19545432192', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (99, NULL, NULL, NULL, '508', 'Time Group Ventures LLC', '17863013101', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (102, NULL, NULL, NULL, '412', 'Sandro Fornasier', '1-917-302-7364', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (104, NULL, NULL, NULL, '608', 'CVOX', '3055734775', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (107, NULL, NULL, NULL, '903', 'Beatriz Velo', '13059008970', '', 'BUICK', 'ROADMASTER/GOLD', '112WNP', NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (109, NULL, NULL, NULL, '811', 'Nuhouse furniture+design', '3055720057', 'INFO@HUHOUSE.COM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (111, NULL, NULL, NULL, '902', 'Linda Suarez', '305 608 6335', '', 'BMW/RED', '325C1', 'FL-875MIH', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (112, NULL, NULL, NULL, '707', 'Veronica Cicero', '1-646-643-2272', 'veronica@anthologyfloristry.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (118, NULL, NULL, NULL, '903', 'Daniel llinas', '13059008502', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (127, NULL, NULL, NULL, '402', 'Tomas Delgado', '7863156442', '', 'Jetta', 'VW', '862JFE', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (128, NULL, NULL, NULL, '605', 'Mikheal Bortz', '7863429883', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (129, NULL, NULL, NULL, '401', 'RealLiving office  (Monday Thru Friday)', '3055731999', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (130, NULL, NULL, NULL, 'p10', 'Darren Kart (DkContemporary)', '3055026664', '', 'BMW', NULL, 'FL-P2206U', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (132, NULL, NULL, NULL, 'p01', 'Kenetra Maffett (Secondary)', '7865431621', '', 'Nissan 2013', 'altima', 'BAW-7342', NULL, NULL, NULL, 'Please only use this number if i dont answer my Primary number. new car paper tag\r\n', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (136, NULL, NULL, NULL, 'p02', 'Fe Maldonado', '19542587184', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (138, NULL, NULL, NULL, '408', 'Nancy Cromar', '3058159228', '', 'red mini', NULL, '512hpe', NULL, NULL, NULL, 'Steve Pynes allowed access at all time.', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (139, NULL, NULL, NULL, '408', 'Dan Owens ( NC Studios)', '3056109490', '', '04 Jeep', ' Liberty', 'atgx45', 'Mini cooper (red)', 'Cooper', NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (140, NULL, NULL, NULL, '408', 'NC studios (office)', '3055766888', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (183, NULL, NULL, NULL, '307', 'Roselena', '14074354021', '', 'HYUNDAI', 'SONATA/ SKYBLUE', 'ATK-X26', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (168, NULL, NULL, NULL, '604', 'Jennifer Colon', '1-954-892-1847', '', NULL, NULL, NULL, NULL, NULL, NULL, 'Allowed Adrian to go up anytime:', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (142, NULL, NULL, NULL, '202', 'Justin Peter Burrows', '13053083085', 'justinpburrows@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (153, NULL, NULL, NULL, '806', 'Dan Owens', '13056098184', '', 'Toyota Prius', 'C4', 'ATGX45', NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (254, NULL, NULL, NULL, '804', 'Bernard Macker', '13057660007', 'BernardMacker@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (266, NULL, NULL, NULL, '808', 'Jorge Pernas (CUBE2 OFFICE)', '17862352720', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (156, NULL, NULL, NULL, '610', 'Daniel Hassan', '561-997-4388', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (158, NULL, NULL, NULL, '409', 'Melinda Cowen ', '305-333-7344', 'cowensdesign@mindspring.com', 'HYUNDAI', 'SANTAFE/ GREEN', '729-XIE', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (159, NULL, NULL, NULL, '409', 'Cowen Design', '305-573-9838', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (160, NULL, NULL, NULL, 'p07', 'Alvaro Maldonado', '13057446161', '', NULL, NULL, NULL, NULL, NULL, NULL, '305-503-5925', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (164, NULL, '000', 'test only', '000', 'luis leon v', '3054015393', 'only for test', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (235, NULL, NULL, NULL, '906', 'Kristen Klein', '17863973735', '', 'Jeep (black)', 'Liberty', NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (242, NULL, NULL, NULL, '607', 'Rhonda Philp', '17862463334', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (174, NULL, NULL, NULL, '702', 'Paula Hernandez', '3053350414', '', NULL, NULL, NULL, NULL, NULL, NULL, 'To be called on this number# when calling for building access!\r\n', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (329, NULL, NULL, NULL, '1001', 'Kenetra Kayanna - Hair Salon', '17865431621', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (269, NULL, NULL, NULL, '304', 'Kenetra kayanna (Kookie)', '17865431621', 'kenetramaffet@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (179, NULL, NULL, NULL, '311', 'Yancho Chenkov', '1(954)696-1873', '', 'Toyota', 'Camry', 'I26-7AI', NULL, NULL, NULL, 'Family Are Allowed In Names Below:\r\nZhechka Chenkova\r\nNikolay Georgiev\r\n954 305 6347', NULL, 3);
INSERT INTO `tbl_tennants` VALUES (181, NULL, NULL, NULL, '506', 'Christin Minnotte', '19179230515', '', NULL, NULL, NULL, NULL, NULL, NULL, 'mother is allowed\r\neverybody else call', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (328, NULL, NULL, NULL, '905', 'JLI & Associates', '17862030208', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (186, NULL, NULL, NULL, '306', 'Juan Luis Arana', '3059519193', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (187, NULL, NULL, NULL, '306', 'Kenny Agredo', '3057784432', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (188, NULL, NULL, NULL, '606', 'Adam Borocas', '15165785474', '', 'BMW', '545I / WHITE', '859-XNN', NULL, NULL, NULL, 'DECAL# PENDING', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (189, NULL, NULL, NULL, '305', 'Janette Miller (Call last)', '3055029900', '', NULL, NULL, NULL, NULL, NULL, NULL, 'CALL JANETTE MILLER LAST!!!!(CALL J.M. DESIGNS FIRST # 305-667-9788)(CALL JESSICA BODE SECOND # 786-271-46600 (JENNIFER ALLOWED IN: 9548655988)', NULL, 3);
INSERT INTO `tbl_tennants` VALUES (221, NULL, NULL, NULL, '611', 'Ramon Avlar', '7862539150', '', NULL, NULL, NULL, NULL, NULL, NULL, 'Rodner Figueroa is allowed without calling.\r\n', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (327, NULL, NULL, NULL, '904', 'Eduardo Valdespino', '19154337947', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (240, NULL, NULL, NULL, '206', 'Erika Shantz', '13106635261', 'erikashantz@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (193, NULL, NULL, NULL, '608', 'alejandra slatapolsky', '3055734775', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (194, NULL, NULL, NULL, '608', 'Maria Laura Mancuso    CVOX company', '3055734775,    cell  305-310-6425', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (323, NULL, NULL, NULL, '505', 'Leopoldo Lavazza', '19546467698', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (232, NULL, NULL, NULL, '509', 'Penelope Morcillo', '13058908308', '', NULL, NULL, NULL, NULL, NULL, NULL, '13058908308', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (324, NULL, NULL, NULL, '507', 'Joshep M Cifelli', '16099338791', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (201, NULL, NULL, NULL, '305', 'J.M.Design', '13058542224', '', NULL, NULL, NULL, NULL, NULL, NULL, 'CALL JANETTE MILLER LAST!!!!(CALL J.M. DESIGNS FIRST # 305-667-9788)(CALL JESSICA BODE SECOND # 786-271-46600 (JENNIFER ALLOWED IN: 9548655988)', NULL, 3);
INSERT INTO `tbl_tennants` VALUES (268, NULL, NULL, NULL, '301', 'Barry Carpe, COO', '1(703)868-1750', 'barry@synktgames.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (204, NULL, NULL, NULL, 'p01', 'Chyna', '786-877-7622', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (207, NULL, NULL, NULL, '303', 'Zach Du Verney', '13055468273', 'zduverney@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (208, NULL, NULL, NULL, '303', 'Melany Garcia', '17876493182', 'g.melany88@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (219, NULL, NULL, NULL, '210', 'Miguel Diaz Pimentel', '13212235452', 'mdiaz@actium.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (257, NULL, NULL, NULL, '609', 'Daryl Waver', '13055056030', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (214, NULL, NULL, NULL, '812', 'Pablo Gonzalez', '13059923130', 'pgonzalez@arellanogc.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (215, NULL, NULL, NULL, '812', 'Martha Lluch', '13473353231', 'martha.lluch@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (294, NULL, NULL, NULL, '809', 'Ronald Saint-Vil', '17865536462', 'djsaintchill@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (267, NULL, NULL, NULL, '301', 'Bryan Abboud, CEO', '1(305)490-2878', 'BA@synktgames.com', NULL, NULL, NULL, NULL, NULL, NULL, 'Paul Kyuger is not Allowed in the unit or property,\r\ncall for everyone who comes up\r\n', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (291, NULL, NULL, NULL, '708', 'Luis Ernesto Pinol', '13059049906', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (255, NULL, NULL, NULL, '905', 'Cesar Giral', '7862388887', 'cesar@diabetv.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (256, NULL, NULL, NULL, '609', 'Joseph Gonzalez', '17863762985', '', NULL, NULL, NULL, NULL, NULL, NULL, '13057588627', NULL, 3);
INSERT INTO `tbl_tennants` VALUES (220, NULL, NULL, NULL, 'p05', 'Veronica Maldonado', '19544659331', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (222, NULL, NULL, NULL, '908', 'Sonali Punales', '7863429275', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (223, NULL, NULL, NULL, '204', 'Richard Bassett', '19144191052', 'richardmbassett@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 'Joanne Bassett(mother)', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (224, NULL, NULL, NULL, 'P12', 'Ari Goods', '12392138149', 'arigood@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (310, NULL, NULL, NULL, '312', 'Karen Valencia', '7869161758', 'karoline131@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (226, NULL, NULL, NULL, '504', 'Alessandro Fracas - Dermophisiologique', '13045525807', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (228, NULL, NULL, NULL, '504', 'Maria Sang (call First)', '7863908394', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (229, NULL, NULL, NULL, '308', 'Liane Crawford-Smith', '19412707884', '', 'Lexus', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (231, NULL, NULL, NULL, 'p05', 'Samuel Maldonado', '17862095452', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (233, NULL, NULL, NULL, '704', 'Gianfranco Nicolci', '19545514681', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (234, NULL, NULL, NULL, '704', 'Veroncia Pena', '19548229157', 'veroncia.pena@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (238, NULL, NULL, NULL, '510', 'Lou Dickson', '13472765805', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (239, NULL, NULL, NULL, '307', 'Elio Munaretto', '7862095484', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (245, NULL, NULL, NULL, 'p01', 'Ellie Rezapolri', '13054913231', '', NULL, NULL, NULL, NULL, NULL, NULL, 'WWW.ellie''s Beauty.com', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (292, NULL, NULL, NULL, '708', 'Bailout Printing Co.', '13057484885', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (249, NULL, NULL, NULL, '310', 'Oswaldo Rodriguez', '7862522797', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (251, NULL, NULL, NULL, '302', 'Hector J Arencibia, MYUPPM LLC', '1(305)586-0523', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (252, NULL, NULL, NULL, '808', 'Jorge Pernas', '1-305-586-8169', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (258, NULL, NULL, NULL, '511', 'Brittney Samuels', '13058780931', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (259, NULL, NULL, NULL, '511', 'Brad Low', '13059792494', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (260, NULL, NULL, NULL, 'p01', 'Lockie', '786-383-1655', '', NULL, NULL, NULL, NULL, NULL, NULL, 'new hair dresser\r\n', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (261, NULL, NULL, NULL, '512', '"Bo" Bogachan Burak Demirci', '19548515610', 'bodemirci14@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (262, NULL, NULL, NULL, '601', 'Gustavo Berenblum', '13057900191', '', NULL, NULL, NULL, NULL, NULL, NULL, '1-305-331-8076\r\n17864527131', NULL, 3);
INSERT INTO `tbl_tennants` VALUES (263, NULL, NULL, NULL, '601', 'Berenblum Busch Archhitecture', '1-305-379-9994', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (264, NULL, NULL, NULL, '601', 'Claudia Busch', '1-305-379-9994', 'cb@bbamiami.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (271, NULL, NULL, NULL, '809', 'Marcus Pelle', '13057663155', 'Marcuspelle@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (272, NULL, NULL, NULL, '706', 'Nicolas Uribe', '7862507031', 'Nikobe44@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (273, NULL, NULL, NULL, '801', 'Wendy Silva', '13058981021', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (274, NULL, NULL, NULL, '403', 'Realliving Hotel - Odet', '17863396518', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (275, NULL, NULL, NULL, '404', 'Realliving Hotel - Odet', '17863396518', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (276, NULL, NULL, NULL, '406', 'Realliving Hotel', '17863396518', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (277, NULL, NULL, NULL, '411', 'Realliving Hotel', '0000000000', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (278, NULL, NULL, NULL, '602', 'Realliving Hotel', '0000000000', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (279, NULL, NULL, NULL, '703', 'Realliving Hotel', '0000000000', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (280, NULL, NULL, NULL, '802', 'Realliving Hotel', '0000000000', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (281, NULL, NULL, NULL, 'p03', 'Realliving Hotel', '0000000000', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (282, NULL, NULL, NULL, 'p11', 'Realliving Hotel', '0000000000', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (283, NULL, NULL, NULL, 'p09', 'Realliving Hotel', '0000000000', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (284, NULL, NULL, NULL, 'p01', 'Anna', '305-984-9445', '', NULL, NULL, NULL, NULL, NULL, NULL, 'New kookie employee', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (285, NULL, NULL, NULL, '701', 'Felipe Pirela', '13057535580', '', 'NISSAN', 'TITAN/ SILVER', 'FL-P13XE', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (322, NULL, NULL, NULL, '207', 'Olivia J Francis', '13059427626', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (288, NULL, NULL, NULL, '603', 'Jasmine Kerdoudi', '13053331708', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (290, NULL, NULL, NULL, '901', 'Ashley Galand', '12089461022', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (293, NULL, NULL, NULL, '708', 'Antonio Manueco', '13055423451', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (295, NULL, NULL, NULL, '907', 'Leigh Crichton', '19124014439', '', NULL, NULL, NULL, NULL, NULL, NULL, 'call first before calling andrew\r\n', NULL, 3);
INSERT INTO `tbl_tennants` VALUES (296, NULL, NULL, NULL, '907', 'Andrew Bolt (call last)', '12059108008', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (297, NULL, NULL, NULL, '405', 'Luis Luyando', '7865467420', '', NULL, NULL, NULL, NULL, NULL, NULL, '13059268117, 17864626947\r\nAllowed without no Problem:\r\nPeter Klein\r\nLuis Luyando\r\nWilly Martin\r\n', NULL, 3);
INSERT INTO `tbl_tennants` VALUES (299, NULL, NULL, NULL, '501', 'Frederic Martz', '13054671770', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (301, NULL, NULL, NULL, 'p04', 'Derrick Abelland', '15618182655', 'Derrickabellard@gmail.com', 'Lotus', 'Evora', 'VMM-YEA', NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (302, NULL, NULL, NULL, '705', 'Kryssia Cecilia / Kipp Rios ', '7862036818', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (303, NULL, NULL, NULL, '209', 'Hector D''Armas', '17863014614', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (304, NULL, NULL, NULL, 'p01', 'gievanna', '3058037688', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (305, NULL, NULL, NULL, '612', 'Paul Cleary', '3056098184', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (325, NULL, NULL, NULL, '805', 'Ashley L Lorentz', '13057139763', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (311, NULL, NULL, NULL, '407', 'Alex perez', '3057940637', '', NULL, NULL, NULL, NULL, NULL, NULL, '17865486850', NULL, 3);
INSERT INTO `tbl_tennants` VALUES (312, NULL, NULL, NULL, '407', 'Maegan Perez', '7865486850', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (313, NULL, NULL, NULL, '305', 'Jessica', '786-271-4660', '', NULL, NULL, NULL, NULL, NULL, NULL, 'Always call JM Design # first. Then this number. The last # to call would be Jannette Miller. \r\n', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (314, NULL, NULL, NULL, '507', 'Najah Hassan', '305-613-5582', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (321, NULL, NULL, NULL, '204', 'Joanne Bassett', '19142617226', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (316, NULL, NULL, NULL, '611', 'Harley Bauer', '917-698-1100', '', NULL, NULL, NULL, NULL, NULL, NULL, 'Resident of apartment for 3 weeks! Please call for all guests. ', NULL, 1);
INSERT INTO `tbl_tennants` VALUES (317, NULL, NULL, NULL, '203', 'Heather Cook', '12398504009', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (318, NULL, NULL, NULL, '203', 'Rolando Gonzalez', '19548041511', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (319, NULL, NULL, NULL, '610', 'Pricilla Taveras', '774-270-2325', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (320, NULL, NULL, NULL, 'p01', 'Tina', '954-393-9877', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `tbl_tennants` VALUES (330, NULL, NULL, NULL, '1004', 'Derrick Abellard', '15618182655', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (331, NULL, NULL, NULL, '1004', 'Kirill Basov', '15613513650', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_tennants` VALUES (332, NULL, NULL, NULL, '1009', 'Realliving Hotel', '17863396518', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_tennant_msg`
-- 

CREATE TABLE `tbl_tennant_msg` (
  `id_msg` mediumint(8) NOT NULL auto_increment,
  `date_time` varchar(19) collate utf8_unicode_ci NOT NULL,
  `names` varchar(40) collate utf8_unicode_ci NOT NULL,
  `apt` varchar(3) collate utf8_unicode_ci default NULL,
  `phone` varchar(12) collate utf8_unicode_ci default NULL,
  `message` text collate utf8_unicode_ci NOT NULL,
  `user_read` tinyint(2) default '0',
  `date_time_read` varchar(19) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id_msg`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='tennant messages table' AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `tbl_tennant_msg`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_users`
-- 

CREATE TABLE `tbl_users` (
  `id_user` tinyint(3) NOT NULL auto_increment,
  `username` varchar(20) collate utf8_unicode_ci NOT NULL,
  `names` varchar(40) collate utf8_unicode_ci NOT NULL,
  `password` varchar(32) collate utf8_unicode_ci NOT NULL,
  `id_admin` tinyint(2) NOT NULL,
  PRIMARY KEY  (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Users table' AUTO_INCREMENT=30 ;

-- 
-- Dumping data for table `tbl_users`
-- 

INSERT INTO `tbl_users` VALUES (3, 'lleon', 'Luis Leon', '0aa2126a289e0613c35fa885703dae32', 0);
INSERT INTO `tbl_users` VALUES (4, 'junior', 'Junior', '8f3c673d368fed507d5c19ee7dada6fb', 0);
INSERT INTO `tbl_users` VALUES (5, 'security', 'TEMP', '4a7d1ed414474e4033ac29ccb8653d9b', 0);
INSERT INTO `tbl_users` VALUES (7, 'Roy', 'Roy Cordova', '80f7325fa857de62fafe85f7a30273cb', 0);
INSERT INTO `tbl_users` VALUES (27, 'Ace', 'Alcinord Mechel ', 'de88e3e4ab202d87754078cbb2df6063', 5);
INSERT INTO `tbl_users` VALUES (21, 'Sean', 'Sean Olivera', 'c6add13a690b02e509e02fdd55b14506', 0);
INSERT INTO `tbl_users` VALUES (29, 'MarlonG', 'Marlon', '783cbbf7d431a339f73689b1b2467219', 9);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_visitors`
-- 

CREATE TABLE `tbl_visitors` (
  `id_visitor` mediumint(8) NOT NULL auto_increment,
  `id_tennat` smallint(6) NOT NULL,
  `names` varchar(60) collate utf8_unicode_ci NOT NULL,
  `phones` varchar(40) collate utf8_unicode_ci default NULL,
  `autorized` varchar(2) collate utf8_unicode_ci NOT NULL,
  `chapa` varchar(8) collate utf8_unicode_ci default NULL,
  `make` varchar(20) collate utf8_unicode_ci default NULL,
  `model` varchar(20) collate utf8_unicode_ci default NULL,
  `comments` varchar(255) collate utf8_unicode_ci default NULL,
  `id_user` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id_visitor`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='visitor table' AUTO_INCREMENT=369 ;

-- 
-- Dumping data for table `tbl_visitors`
-- 

INSERT INTO `tbl_visitors` VALUES (2, 3, 'junior test', 'test', 'No', '444444', NULL, NULL, 'just testing', 4);
INSERT INTO `tbl_visitors` VALUES (3, 1, 'junior test', NULL, 'No', NULL, NULL, NULL, 'hgvjhfhgfjhgfjhgf test', 4);
INSERT INTO `tbl_visitors` VALUES (4, 24, 'ron suarez', NULL, 'No', NULL, NULL, NULL, NULL, 4);
INSERT INTO `tbl_visitors` VALUES (5, 71, 'zach kapoltra', NULL, 'No', NULL, NULL, NULL, NULL, 6);
INSERT INTO `tbl_visitors` VALUES (6, 75, 'Milany', NULL, 'No', NULL, NULL, NULL, NULL, 6);
INSERT INTO `tbl_visitors` VALUES (7, 71, 'Brianna J.', NULL, 'No', NULL, NULL, NULL, NULL, 6);
INSERT INTO `tbl_visitors` VALUES (8, 14, 'jonah', NULL, 'No', NULL, NULL, NULL, NULL, 6);
INSERT INTO `tbl_visitors` VALUES (9, 65, 'Alexandra', NULL, 'No', NULL, NULL, NULL, NULL, 6);
INSERT INTO `tbl_visitors` VALUES (10, 68, 'Daniel', NULL, 'No', NULL, NULL, NULL, NULL, 6);
INSERT INTO `tbl_visitors` VALUES (11, 78, 'jimmy restaurant owner next door', '3055731505', 'No', NULL, NULL, NULL, 'going to see hugo', 0);
INSERT INTO `tbl_visitors` VALUES (12, 78, 'mark with vertical river', '9543092651', 'No', NULL, NULL, NULL, 'Fixing the waterfall at entrance', 0);
INSERT INTO `tbl_visitors` VALUES (13, 76, 'west', '5613154336', 'No', NULL, NULL, NULL, 'no car', 0);
INSERT INTO `tbl_visitors` VALUES (14, 13, 'wadalupe', '7864884695', 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (15, 90, 'becky', NULL, 'No', NULL, 'acura', 'tl', NULL, 4);
INSERT INTO `tbl_visitors` VALUES (16, 90, 'James', NULL, 'No', NULL, 'Ford', 'Crown Victoria', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (17, 30, 'herent', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (18, 40, 'adel fonseca', NULL, 'No', NULL, 'toyota', 'ramp', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (19, 40, 'segio rangel', NULL, 'No', NULL, 'bmw', '328i', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (20, 66, 'kerent', NULL, 'No', NULL, NULL, 'lexus', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (21, 39, 'mauricio', NULL, 'No', NULL, 'nissan', 'estera', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (22, 48, 'nestor', NULL, 'No', NULL, 'camry', 'toyota', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (23, 82, 'Niko', NULL, 'No', NULL, NULL, 'Bmw', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (24, 76, 'brendon', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (25, 36, 'gaby ', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (26, 58, 'betty', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (27, 82, 'Ray', NULL, 'No', NULL, 'Nissan', 'Blk', 'Visitor', 6);
INSERT INTO `tbl_visitors` VALUES (28, 30, 'Eli', NULL, 'No', NULL, 'SLVR', NULL, 'Something wrong with unit phone.', 6);
INSERT INTO `tbl_visitors` VALUES (29, 6, 'Amy', NULL, 'No', NULL, NULL, NULL, 'Drop off', 6);
INSERT INTO `tbl_visitors` VALUES (30, 79, 'Carlina ', NULL, 'No', NULL, NULL, NULL, 'Wait in Lobby for Unit.', 6);
INSERT INTO `tbl_visitors` VALUES (31, 10, 'Viviana ', NULL, 'No', NULL, NULL, NULL, NULL, 6);
INSERT INTO `tbl_visitors` VALUES (32, 1, 'Paula ', NULL, 'No', NULL, NULL, NULL, 'Walk-In', 6);
INSERT INTO `tbl_visitors` VALUES (33, 6, 'Danny', NULL, 'No', NULL, NULL, 'SUV', NULL, 6);
INSERT INTO `tbl_visitors` VALUES (34, 10, 'Nancy', NULL, 'No', NULL, NULL, NULL, 'Visit', 6);
INSERT INTO `tbl_visitors` VALUES (35, 81, 'Chanel ', NULL, 'No', NULL, NULL, NULL, 'Visit Kookie', 6);
INSERT INTO `tbl_visitors` VALUES (36, 26, 'Porez Pizza', NULL, 'No', NULL, NULL, NULL, 'Delivery ', 6);
INSERT INTO `tbl_visitors` VALUES (37, 56, 'Lerones Food', NULL, 'No', NULL, NULL, NULL, 'Delivery', 6);
INSERT INTO `tbl_visitors` VALUES (38, 4, 'Ricardo ', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 6);
INSERT INTO `tbl_visitors` VALUES (39, 66, 'Samantha ', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 6);
INSERT INTO `tbl_visitors` VALUES (40, 14, 'Franky', NULL, 'No', NULL, NULL, NULL, 'Visitor', 6);
INSERT INTO `tbl_visitors` VALUES (41, 76, 'BC', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 6);
INSERT INTO `tbl_visitors` VALUES (42, 81, 'Rita', NULL, 'No', NULL, NULL, NULL, 'Visitor', 6);
INSERT INTO `tbl_visitors` VALUES (43, 81, 'Ebony', NULL, 'No', NULL, NULL, NULL, 'Visitor', 6);
INSERT INTO `tbl_visitors` VALUES (44, 10, 'Brabara', NULL, 'No', NULL, NULL, NULL, 'Visitor', 6);
INSERT INTO `tbl_visitors` VALUES (45, 81, 'Indura ', NULL, 'No', NULL, NULL, NULL, 'Visitor', 6);
INSERT INTO `tbl_visitors` VALUES (46, 10, 'Gerald ', NULL, 'No', NULL, NULL, NULL, 'Visitor', 6);
INSERT INTO `tbl_visitors` VALUES (47, 10, 'Frank', NULL, 'No', NULL, NULL, NULL, NULL, 6);
INSERT INTO `tbl_visitors` VALUES (48, 78, 'Gold Key', NULL, 'No', NULL, NULL, NULL, 'Pick up check ', 6);
INSERT INTO `tbl_visitors` VALUES (49, 96, 'Jason', NULL, 'No', NULL, NULL, NULL, 'Visitor', 6);
INSERT INTO `tbl_visitors` VALUES (50, 19, 'Chinese ', NULL, 'No', NULL, NULL, NULL, 'Delivery', 6);
INSERT INTO `tbl_visitors` VALUES (51, 14, 'Kimberly', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 6);
INSERT INTO `tbl_visitors` VALUES (52, 58, 'Greg', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 6);
INSERT INTO `tbl_visitors` VALUES (53, 16, 'Nesto ', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 6);
INSERT INTO `tbl_visitors` VALUES (54, 26, 'Chinese', NULL, 'No', NULL, NULL, NULL, 'Delivery ', 6);
INSERT INTO `tbl_visitors` VALUES (55, 18, 'ezzio ', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (56, 54, 'omar ', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (57, 80, 'linzi', NULL, 'No', NULL, 'honda', 'civic', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (58, 36, 'alan ', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (59, 40, 'claudio', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (60, 95, 'jaime', NULL, 'No', NULL, 'audi', 'a4', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (61, 8, 'michael', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (62, 1, 'andy', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (63, 30, 'eli', NULL, 'No', NULL, 'nissan', 'altima', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (64, 13, 'quadalupe', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (65, 82, 'niko', NULL, 'No', NULL, NULL, 'bmw', NULL, 9);
INSERT INTO `tbl_visitors` VALUES (66, 76, 'Helen', NULL, 'No', NULL, NULL, NULL, 'Visitor', 9);
INSERT INTO `tbl_visitors` VALUES (67, 80, 'Devin', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 9);
INSERT INTO `tbl_visitors` VALUES (68, 17, 'Jose', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 9);
INSERT INTO `tbl_visitors` VALUES (69, 61, 'Amanda', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 9);
INSERT INTO `tbl_visitors` VALUES (70, 97, 'Juilian ', NULL, 'No', NULL, NULL, NULL, 'Visitor ', 9);
INSERT INTO `tbl_visitors` VALUES (71, 81, 'tiffany', NULL, 'No', NULL, 'ford', 'mustang', NULL, 4);
INSERT INTO `tbl_visitors` VALUES (72, 27, 'leo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (73, 9, 'JOVANY', NULL, 'No', NULL, 'BMW', NULL, NULL, 4);
INSERT INTO `tbl_visitors` VALUES (74, 78, 'eloy paredes', NULL, 'No', NULL, 'nissan', NULL, NULL, 4);
INSERT INTO `tbl_visitors` VALUES (75, 81, 'shantel', NULL, 'No', NULL, 'ford', NULL, NULL, 4);
INSERT INTO `tbl_visitors` VALUES (76, 1, 'pablo', NULL, 'No', NULL, 'madza', '2', NULL, 4);
INSERT INTO `tbl_visitors` VALUES (77, 81, 'candis', NULL, 'No', NULL, 'bmw', NULL, NULL, 4);
INSERT INTO `tbl_visitors` VALUES (78, 6, 'michel', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (79, 76, 'katty', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (80, 76, 'allen', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (81, 99, 'william delgado', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (82, 76, 'randy', NULL, 'No', NULL, 'charger', NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (83, 60, 'demian', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (84, 83, 'rosa', NULL, 'No', NULL, 'no car', NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (85, 56, 'maria', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (86, 11, 'carlos', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (87, 73, 'direc tv isaul', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (88, 10, 'louis f.', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (89, 6, 'michel', NULL, 'No', NULL, 'bmw', '750', NULL, 13);
INSERT INTO `tbl_visitors` VALUES (90, 10, 'tony ', NULL, 'No', NULL, 'walk in', NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (91, 10, 'tim', NULL, 'No', NULL, 'ford', NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (92, 83, 'alvaro d.', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (93, 13, 'greg', NULL, 'No', NULL, 'ford', NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (94, 10, 'juda', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (95, 71, 'alx', NULL, 'No', NULL, NULL, 'bmw', NULL, 13);
INSERT INTO `tbl_visitors` VALUES (96, 71, 'monica', NULL, 'No', NULL, 'walk n', NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (97, 10, 'andy', NULL, 'No', NULL, NULL, 'walk n', NULL, 13);
INSERT INTO `tbl_visitors` VALUES (98, 76, 'deanna', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (99, 27, 'j', NULL, 'No', NULL, ' bmw', NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (100, 82, 'jack', NULL, 'No', NULL, 'bmw', NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (101, 15, 'sady', NULL, 'No', NULL, 'jeep', NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (102, 14, 'loreina', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (103, 76, 'daniela', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (104, 63, 'jasmen', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (105, 34, 'shery', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (106, 4, 'angelo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (107, 80, 'ashely', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (108, 59, 'wiliam', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (109, 8, 'CHANE GREEN (AND COMPANY)', NULL, 'No', NULL, NULL, NULL, 'ALLOWED IN FROM 8/15/11 TO 8/17/11\r\nNO VECHILE ADMITED', 7);
INSERT INTO `tbl_visitors` VALUES (110, 97, 'mery ibanez', NULL, 'No', NULL, NULL, NULL, NULL, 5);
INSERT INTO `tbl_visitors` VALUES (111, 97, 'Ninoak ibanez', NULL, 'No', NULL, NULL, NULL, NULL, 5);
INSERT INTO `tbl_visitors` VALUES (112, 52, 'Ronnie Pryor', NULL, 'No', NULL, NULL, NULL, 'Allow in anytime!', 7);
INSERT INTO `tbl_visitors` VALUES (113, 59, 'robert', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (114, 82, 'raynaldo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (115, 82, 'eduardo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (116, 82, 'nick', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (117, 58, 'eric perez', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (118, 73, 'victor daly', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (119, 95, 'tatianna', NULL, 'No', NULL, 'motorc', NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (120, 36, 'juan', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (121, 96, 'lazaro ', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (122, 97, 'zabat', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (123, 80, 'alet', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (124, 80, 'devin', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (125, 20, 'isador', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (126, 80, 'chris', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (127, 14, 'silvia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (128, 66, 'alex', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (129, 48, 'dasfeny', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (130, 67, 'gabriel', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (131, 76, 'canon', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (132, 81, 'rochelle flecther', NULL, 'No', NULL, NULL, 'mini cooper', NULL, 5);
INSERT INTO `tbl_visitors` VALUES (133, 37, 'chris nelson', '3478693320', 'No', 'rental p', 'dodge', 'charger (black)', 'staying till 08/29/11', 7);
INSERT INTO `tbl_visitors` VALUES (134, 13, 'louis carrillo', NULL, 'No', NULL, NULL, NULL, NULL, 5);
INSERT INTO `tbl_visitors` VALUES (135, 76, 'jc casely', NULL, 'No', NULL, NULL, NULL, NULL, 5);
INSERT INTO `tbl_visitors` VALUES (136, 80, 'eric', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (137, 4, 'juan', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (138, 4, 'siol', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (139, 60, 'eddy', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (140, 67, 'gray', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (141, 76, 'michel', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (142, 59, 'china', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (143, 79, 'markis', NULL, 'No', NULL, NULL, 'tc', NULL, 5);
INSERT INTO `tbl_visitors` VALUES (144, 76, 'D.Q', NULL, 'No', NULL, 'none', NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (145, 30, 'Ely', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (146, 4, 'Ricardo', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (147, 96, 'cristina', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (148, 56, 'kenia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (149, 76, 'chris', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (150, 6, 'julia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (151, 81, 'LISA', 'none', 'No', 'none', 'none', 'none', 'client', 7);
INSERT INTO `tbl_visitors` VALUES (152, 82, 'tommy', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (153, 47, 'angel rodriguez', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (154, 8, 'larneol', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (155, 6, 'carmen', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (156, 34, 'sebastian', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (157, 4, 'omar', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (158, 75, 'neol', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (159, 105, 'ben', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (160, 105, 'elisabet', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (161, 105, 'alex', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (162, 41, 'jhon', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (163, 41, 'eduint', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (164, 52, 'dina', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (165, 82, 'miquel', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (166, 82, 'briyan', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (167, 61, 'maura', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (168, 82, 'cristina', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (169, 82, 'rafael', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (170, 82, 'edde', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (171, 24, 'primo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (172, 10, 'vannesa ray', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (173, 79, 'Mr. Martinez', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (174, 76, 'brandon le', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (175, 21, 'daily food delivery ana', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (176, 10, 'samantha skye', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (177, 81, 'lisa', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (178, 45, 'Mr. Diaz', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (179, 79, 'Ms. Aliver', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (180, 81, 'shuris', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (181, 81, 'annie', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (182, 79, 'othneol', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (183, 84, 'luis', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (184, 76, 'keigy', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (185, 6, 'danny', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (186, 57, 'joe carden', NULL, 'No', NULL, NULL, NULL, 'Dont Call just let him in ', 0);
INSERT INTO `tbl_visitors` VALUES (187, 6, 'jessy', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (188, 6, 'lia ', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (189, 111, 'lisandra', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (190, 111, 'alex', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (191, 82, 'alan', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (192, 80, 'lorena', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (193, 15, 'edalys', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (194, 80, 'tatiana', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (195, 80, 'vanesa', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (196, 48, 'jesel', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (197, 14, 'will', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (198, 30, 'Eli', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (199, 80, 'kaisy', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (200, 81, 'nicole', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (201, 80, 'danny', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (202, 81, 'ailin', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (203, 101, 'mario', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (204, 54, 'paul', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (205, 101, 'jenifer', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (206, 27, 'jorge', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (207, 15, 'jinet', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (208, 64, 'sofia', NULL, 'No', NULL, NULL, NULL, NULL, 4);
INSERT INTO `tbl_visitors` VALUES (209, 71, 'eric', NULL, 'No', NULL, NULL, NULL, NULL, 4);
INSERT INTO `tbl_visitors` VALUES (210, 71, 'ms richerd', NULL, 'No', NULL, 'bmw', '325', NULL, 4);
INSERT INTO `tbl_visitors` VALUES (211, 53, 'david araugo', NULL, 'No', NULL, 'motorcycle ', 'ninja', NULL, 7);
INSERT INTO `tbl_visitors` VALUES (212, 79, 'Rebeka', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (213, 14, 'luan ', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (214, 15, 'jenet', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (215, 106, 'maria', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (216, 93, 'oga', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (217, 19, 'Chinese', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (218, 118, 'Greg & Debbie', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (219, 111, 'ana', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (220, 65, 'Ingrid Parra', '7542442038', 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (221, 93, 'Jorge', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (222, 111, 'Oscar', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (223, 60, 'roberto', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (224, 34, 'tao', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (225, 8, 'cj', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (226, 65, 'alicia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (227, 79, 'paul', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (228, 79, 'kevin', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (229, 79, 'ambros', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (230, 79, 'leandro', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (231, 79, 'erenda', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (232, 6, 'quillermo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (233, 54, 'shean', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (234, 6, 'roby', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (235, 79, 'julia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (236, 63, 'many', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (237, 56, 'daniel', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (238, 56, 'deby', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (239, 81, 'adria', NULL, 'No', NULL, NULL, NULL, NULL, 5);
INSERT INTO `tbl_visitors` VALUES (240, 106, 'nenet', NULL, 'No', NULL, NULL, NULL, NULL, 5);
INSERT INTO `tbl_visitors` VALUES (241, 82, 'paloma fernandez', NULL, 'No', NULL, NULL, NULL, NULL, 5);
INSERT INTO `tbl_visitors` VALUES (242, 36, 'maribel', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (243, 33, 'marta', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (244, 74, 'ilda', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (245, 59, 'alex', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (246, 10, 'rodriquez', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (247, 13, 'an', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (248, 10, 'meryori', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (249, 73, 'tabard', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (250, 109, 'mailin', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (251, 10, 'kaidy', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (252, 10, 'alesia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (253, 10, 'ana', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (254, 24, 'tobais', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (255, 56, 'Maria', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (256, 10, 'gia renai', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (257, 104, 'joey', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (258, 79, 'ivet', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (259, 73, 'tavar', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (260, 60, 'juan', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (261, 48, 'arturo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (262, 48, 'gorje', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (263, 54, 'nick', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (264, 6, 'carlos', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (265, 56, 'jeff', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (266, 56, 'alan', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (267, 79, 'michele', NULL, 'No', NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_visitors` VALUES (268, 80, 'evon', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (269, 48, 'Alex', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (270, 10, 'camila', NULL, 'No', NULL, NULL, NULL, NULL, 0);
INSERT INTO `tbl_visitors` VALUES (271, 111, 'john', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (272, 65, 'tiger', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (273, 27, 'dario', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (274, 61, 'kalin', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (275, 80, 'debit', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (276, 53, 'forest', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (277, 4, 'daisy', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (278, 4, 'eduardo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (279, 27, 'neit', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (280, 117, 'jovani', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (281, 117, 'juan', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (282, 30, 'Eli', NULL, 'No', NULL, NULL, NULL, NULL, 10);
INSERT INTO `tbl_visitors` VALUES (283, 34, 'Michael', NULL, 'No', NULL, NULL, NULL, NULL, 10);
INSERT INTO `tbl_visitors` VALUES (284, 118, 'Gabriel', NULL, 'No', NULL, NULL, NULL, NULL, 10);
INSERT INTO `tbl_visitors` VALUES (285, 118, 'kari y roberto', NULL, 'No', NULL, NULL, NULL, NULL, 10);
INSERT INTO `tbl_visitors` VALUES (286, 118, 'pablo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (287, 15, 'fernando', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (288, 15, 'carolin', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (289, 15, 'yulisa', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (290, 15, 'seles', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (291, 60, 'james', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (292, 81, 'shurine', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (293, 36, 'warte', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (294, 36, 'sam', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (295, 126, 'sintia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (296, 126, 'ralnold', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (297, 8, 'mikel', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (298, 22, 'victoria', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (299, 8, 'devinia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (300, 22, 'acturo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (301, 107, 'Andres', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (302, 60, 'caol', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (303, 27, 'rey', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (304, 111, 'natalie geller', NULL, 'No', NULL, 'range rover', NULL, NULL, 5);
INSERT INTO `tbl_visitors` VALUES (305, 111, 'daniel', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (306, 8, 'jose', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (307, 93, 'lilia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (308, 117, 'limo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (309, 61, 'elisabet', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (310, 76, 'elisabet', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (311, 20, 'critofer', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (312, 118, 'carmen', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (313, 76, 'cristina', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (314, 2, 'kemuel', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (315, 126, 'files', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (316, 61, 'robt', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (317, 118, 'mike', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (318, 27, 'alex', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (319, 69, 'marcos', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (320, 101, 'daniela', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (321, 127, 'albert', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (322, 33, 'diego', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (323, 8, 'federico', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (324, 117, 'miriela', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (325, 122, 'alfredo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (326, 65, 'daniel', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (327, 80, 'guy', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (328, 18, 'gonzalo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (329, 61, 'sintia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (330, 36, 'hector', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (331, 36, 'ricardo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (332, 1, 'geleri', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (333, 64, 'martin', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (334, 30, 'analicia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (335, 8, 'hassan riggs', NULL, 'No', NULL, NULL, NULL, NULL, 5);
INSERT INTO `tbl_visitors` VALUES (336, 34, 'brent', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (337, 23, 'amor', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (338, 65, 'lionardo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (339, 10, 'cladia', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (340, 10, 'jonathan', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (341, 99, 'eduardo', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (342, 101, 'david', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (343, 71, 'lisa', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (344, 122, 'eba', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (345, 80, 'starlin', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (346, 41, 'juaqin', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (347, 20, 'olga', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (348, 69, 'renato', NULL, 'No', NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_visitors` VALUES (349, 73, 'Jessica', NULL, 'No', NULL, NULL, NULL, NULL, 15);
INSERT INTO `tbl_visitors` VALUES (350, 4, 'Lesley', NULL, 'No', NULL, NULL, NULL, NULL, 15);
INSERT INTO `tbl_visitors` VALUES (351, 10, 'Damon Simentelli', NULL, 'No', NULL, NULL, NULL, NULL, 15);
INSERT INTO `tbl_visitors` VALUES (352, 4, 'Alejandro', NULL, 'No', NULL, NULL, NULL, NULL, 15);
INSERT INTO `tbl_visitors` VALUES (353, 68, 'Angelis', NULL, 'No', NULL, NULL, NULL, NULL, 15);
INSERT INTO `tbl_visitors` VALUES (354, 117, 'paula hernandez', '30543350414', 'No', NULL, NULL, NULL, 'tennant that live in there is paula hernandez', 20);
INSERT INTO `tbl_visitors` VALUES (355, 105, 'Josh ', NULL, 'No', NULL, NULL, NULL, 'per Mr. Simpson (06/25/2013 5:24pm) Josh is allowed up without calling first', 20);
INSERT INTO `tbl_visitors` VALUES (356, 135, 'Norma Spencer', NULL, 'No', NULL, NULL, NULL, 'Following guest are allowed into unit if Mr. Spencer is not availible. Always call as usual. Leave message if no answer.', 21);
INSERT INTO `tbl_visitors` VALUES (357, 135, 'Jermaine Spencer', NULL, 'No', NULL, NULL, NULL, 'The following guests are allowed into the unit. Always call first as usual. If no answer then leave detailed message as to who and when.', 21);
INSERT INTO `tbl_visitors` VALUES (358, 135, 'Clint Rutherford', NULL, 'No', NULL, NULL, NULL, 'The following guests are allowed into the unit. Always call first as usual. If no answer then leave detailed message as to who and when.', 21);
INSERT INTO `tbl_visitors` VALUES (359, 135, 'Maria Bucherelli', NULL, 'No', NULL, NULL, NULL, 'The following guests are allowed into the unit. Always call first as usual. If no answer then leave detailed message as to who and when.', 21);
INSERT INTO `tbl_visitors` VALUES (360, 205, 'Tila', '7188095711', 'No', NULL, NULL, NULL, NULL, 20);
INSERT INTO `tbl_visitors` VALUES (361, 221, 'Rodner Figueroa', NULL, 'No', NULL, NULL, NULL, 'Is Allowed in anytime and anyday,his mom is staying with ramon\r\n', 20);
INSERT INTO `tbl_visitors` VALUES (362, 221, 'Enucaris Rigual ', NULL, 'No', NULL, NULL, NULL, 'IS allowed with out any problems\r\n', 20);
INSERT INTO `tbl_visitors` VALUES (363, 205, 'Kiari Campbell', NULL, 'No', NULL, NULL, NULL, 'Vistior Family', 20);
INSERT INTO `tbl_visitors` VALUES (364, 205, 'Patrick Fan Fan ', '19737807910', 'No', NULL, NULL, NULL, 'Visitor Family', 20);
INSERT INTO `tbl_visitors` VALUES (365, 247, 'sonia Lopez ', NULL, 'No', NULL, NULL, NULL, 'IS STAYING FOR A COUPLE OF DAYS IN NANCY MENDEZ UNIT GIVE ALL PACKAGE TO HER....', 20);
INSERT INTO `tbl_visitors` VALUES (366, 301, 'DOMIMIQUE FRANCOIS ', NULL, 'No', NULL, NULL, NULL, 'ALLOWED IN ANYTIME\r\n', 20);
INSERT INTO `tbl_visitors` VALUES (367, 301, 'Jael Bernard', NULL, 'No', NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_visitors` VALUES (368, 78, 'Fabiana & Pablo', NULL, 'No', NULL, NULL, NULL, NULL, 5);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_visits`
-- 

CREATE TABLE `tbl_visits` (
  `id_visit` mediumint(8) NOT NULL auto_increment,
  `id_visitor` mediumint(8) NOT NULL,
  `visit_date` varchar(19) collate utf8_unicode_ci NOT NULL,
  `comments` varchar(255) collate utf8_unicode_ci default NULL,
  `id_usuario` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id_visit`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='tabla de visitas' AUTO_INCREMENT=165 ;

-- 
-- Dumping data for table `tbl_visits`
-- 

INSERT INTO `tbl_visits` VALUES (2, 2, '07/22/2011-9:09:19', NULL, 3);
INSERT INTO `tbl_visits` VALUES (3, 16, '07/29/2011-23:23:16', NULL, 9);
INSERT INTO `tbl_visits` VALUES (4, 27, '08/01/2011-21:21:27', NULL, 6);
INSERT INTO `tbl_visits` VALUES (5, 29, '08/04/2011-13:13:57', NULL, 6);
INSERT INTO `tbl_visits` VALUES (6, 30, '08/04/2011-13:13:46', NULL, 6);
INSERT INTO `tbl_visits` VALUES (7, 31, '08/04/2011-14:14:32', NULL, 6);
INSERT INTO `tbl_visits` VALUES (8, 32, '08/04/2011-14:14:28', NULL, 6);
INSERT INTO `tbl_visits` VALUES (9, 33, '08/04/2011-15:15:32', NULL, 6);
INSERT INTO `tbl_visits` VALUES (10, 34, '08/04/2011-15:15:42', NULL, 6);
INSERT INTO `tbl_visits` VALUES (11, 35, '08/04/2011-16:16:54', NULL, 6);
INSERT INTO `tbl_visits` VALUES (12, 36, '08/04/2011-17:17:32', NULL, 6);
INSERT INTO `tbl_visits` VALUES (13, 37, '08/04/2011-18:18:59', NULL, 6);
INSERT INTO `tbl_visits` VALUES (14, 38, '08/04/2011-18:18:53', 'Visitor ', 6);
INSERT INTO `tbl_visits` VALUES (15, 20, '08/04/2011-19:19:07', NULL, 6);
INSERT INTO `tbl_visits` VALUES (16, 39, '08/04/2011-19:19:20', NULL, 6);
INSERT INTO `tbl_visits` VALUES (17, 40, '08/04/2011-20:20:22', NULL, 6);
INSERT INTO `tbl_visits` VALUES (18, 13, '08/04/2011-20:20:29', NULL, 6);
INSERT INTO `tbl_visits` VALUES (19, 41, '08/04/2011-20:20:01', 'Visitor', 6);
INSERT INTO `tbl_visits` VALUES (20, 42, '08/04/2011-20:20:36', 'Visitor ', 6);
INSERT INTO `tbl_visits` VALUES (21, 43, '08/05/2011-13:13:14', NULL, 6);
INSERT INTO `tbl_visits` VALUES (22, 44, '08/05/2011-14:14:00', 'Visit', 6);
INSERT INTO `tbl_visits` VALUES (23, 45, '08/05/2011-14:14:49', 'Visit', 6);
INSERT INTO `tbl_visits` VALUES (24, 46, '08/05/2011-14:14:36', 'Visitor', 6);
INSERT INTO `tbl_visits` VALUES (25, 47, '08/05/2011-15:15:13', 'Visit', 6);
INSERT INTO `tbl_visits` VALUES (26, 48, '08/05/2011-15:15:04', 'Pick up check ', 6);
INSERT INTO `tbl_visits` VALUES (27, 49, '08/05/2011-16:16:27', 'Visitor', 6);
INSERT INTO `tbl_visits` VALUES (28, 50, '08/05/2011-17:17:41', 'Delivery', 6);
INSERT INTO `tbl_visits` VALUES (29, 51, '08/05/2011-18:18:40', 'Visitor ', 6);
INSERT INTO `tbl_visits` VALUES (30, 52, '08/05/2011-19:19:47', 'Visitor', 6);
INSERT INTO `tbl_visits` VALUES (31, 53, '08/05/2011-19:19:01', 'Visitor', 6);
INSERT INTO `tbl_visits` VALUES (32, 54, '08/05/2011-20:20:57', 'Delivery ', 6);
INSERT INTO `tbl_visits` VALUES (33, 23, '08/07/2011-20:20:13', NULL, 9);
INSERT INTO `tbl_visits` VALUES (34, 23, '08/07/2011-20:20:43', NULL, 9);
INSERT INTO `tbl_visits` VALUES (35, 23, '08/07/2011-20:20:24', NULL, 9);
INSERT INTO `tbl_visits` VALUES (36, 27, '08/07/2011-20:20:36', NULL, 9);
INSERT INTO `tbl_visits` VALUES (37, 66, '08/07/2011-21:21:11', 'Visitor', 9);
INSERT INTO `tbl_visits` VALUES (38, 67, '08/07/2011-21:21:57', 'Visitor\r\n', 9);
INSERT INTO `tbl_visits` VALUES (39, 68, '08/07/2011-21:21:53', 'Visitor ', 9);
INSERT INTO `tbl_visits` VALUES (40, 69, '08/07/2011-21:21:52', 'Visitor ', 9);
INSERT INTO `tbl_visits` VALUES (41, 70, '08/07/2011-22:22:56', 'Visitor ', 9);
INSERT INTO `tbl_visits` VALUES (42, 10, '08/09/2011-14:14:47', NULL, 4);
INSERT INTO `tbl_visits` VALUES (43, 63, '08/11/2011-16:16:28', NULL, 4);
INSERT INTO `tbl_visits` VALUES (44, 23, '08/11/2011-16:16:13', NULL, 4);
INSERT INTO `tbl_visits` VALUES (45, 41, '08/11/2011-21:21:17', NULL, 9);
INSERT INTO `tbl_visits` VALUES (46, 41, '08/11/2011-21:21:05', NULL, 9);
INSERT INTO `tbl_visits` VALUES (47, 33, '08/11/2011-23:23:01', NULL, 9);
INSERT INTO `tbl_visits` VALUES (48, 15, '08/12/2011-8:08:11', NULL, 13);
INSERT INTO `tbl_visits` VALUES (49, 29, '08/12/2011-9:09:36', NULL, 13);
INSERT INTO `tbl_visits` VALUES (50, 21, '08/12/2011-10:10:56', NULL, 13);
INSERT INTO `tbl_visits` VALUES (51, 5, '08/12/2011-12:12:50', NULL, 13);
INSERT INTO `tbl_visits` VALUES (52, 41, '08/12/2011-13:13:11', NULL, 13);
INSERT INTO `tbl_visits` VALUES (53, 74, '08/12/2011-15:15:26', NULL, 13);
INSERT INTO `tbl_visits` VALUES (54, 89, '08/12/2011-15:15:46', NULL, 13);
INSERT INTO `tbl_visits` VALUES (55, 31, '08/12/2011-15:15:49', NULL, 13);
INSERT INTO `tbl_visits` VALUES (56, 60, '08/12/2011-21:21:39', NULL, 9);
INSERT INTO `tbl_visits` VALUES (57, 70, '08/12/2011-22:22:43', NULL, 9);
INSERT INTO `tbl_visits` VALUES (58, 26, '08/13/2011-2:02:16', NULL, 9);
INSERT INTO `tbl_visits` VALUES (59, 61, '08/13/2011-16:16:50', NULL, 9);
INSERT INTO `tbl_visits` VALUES (60, 70, '08/13/2011-18:18:02', NULL, 9);
INSERT INTO `tbl_visits` VALUES (61, 60, '08/13/2011-20:20:18', NULL, 9);
INSERT INTO `tbl_visits` VALUES (62, 79, '08/14/2011-15:15:31', NULL, 9);
INSERT INTO `tbl_visits` VALUES (63, 68, '08/14/2011-19:19:21', NULL, 9);
INSERT INTO `tbl_visits` VALUES (64, 68, '08/15/2011-22:22:27', NULL, 13);
INSERT INTO `tbl_visits` VALUES (65, 82, '08/16/2011-18:18:15', NULL, 7);
INSERT INTO `tbl_visits` VALUES (66, 70, '08/17/2011-12:12:05', NULL, 5);
INSERT INTO `tbl_visits` VALUES (67, 109, '08/17/2011-13:13:08', NULL, 5);
INSERT INTO `tbl_visits` VALUES (68, 70, '08/17/2011-16:16:26', NULL, 7);
INSERT INTO `tbl_visits` VALUES (69, 41, '08/18/2011-14:14:34', NULL, 13);
INSERT INTO `tbl_visits` VALUES (70, 28, '08/18/2011-16:16:06', NULL, 13);
INSERT INTO `tbl_visits` VALUES (71, 27, '08/18/2011-19:19:38', NULL, 13);
INSERT INTO `tbl_visits` VALUES (72, 55, '08/18/2011-20:20:23', NULL, 13);
INSERT INTO `tbl_visits` VALUES (73, 104, '08/19/2011-17:17:23', NULL, 13);
INSERT INTO `tbl_visits` VALUES (74, 68, '08/20/2011-18:18:15', NULL, 9);
INSERT INTO `tbl_visits` VALUES (75, 24, '08/21/2011-15:15:03', NULL, 9);
INSERT INTO `tbl_visits` VALUES (76, 41, '08/22/2011-17:17:17', NULL, 7);
INSERT INTO `tbl_visits` VALUES (77, 41, '08/24/2011-21:21:44', NULL, 9);
INSERT INTO `tbl_visits` VALUES (78, 121, '08/26/2011-22:22:31', NULL, 9);
INSERT INTO `tbl_visits` VALUES (79, 33, '08/28/2011-18:18:42', NULL, 9);
INSERT INTO `tbl_visits` VALUES (80, 131, '08/28/2011-20:20:03', NULL, 9);
INSERT INTO `tbl_visits` VALUES (81, 145, '08/31/2011-17:17:57', 'nissan altima', 0);
INSERT INTO `tbl_visits` VALUES (82, 24, '08/31/2011-21:21:40', NULL, 9);
INSERT INTO `tbl_visits` VALUES (83, 61, '09/03/2011-1:01:27', NULL, 9);
INSERT INTO `tbl_visits` VALUES (84, 55, '09/03/2011-16:16:53', NULL, 9);
INSERT INTO `tbl_visits` VALUES (85, 142, '09/04/2011-18:18:34', NULL, 9);
INSERT INTO `tbl_visits` VALUES (86, 147, '09/08/2011-22:22:47', NULL, 9);
INSERT INTO `tbl_visits` VALUES (87, 23, '09/10/2011-19:19:54', NULL, 7);
INSERT INTO `tbl_visits` VALUES (88, 114, '09/10/2011-20:20:06', NULL, 7);
INSERT INTO `tbl_visits` VALUES (89, 22, '09/10/2011-20:20:29', NULL, 7);
INSERT INTO `tbl_visits` VALUES (90, 58, '09/10/2011-20:20:47', NULL, 7);
INSERT INTO `tbl_visits` VALUES (91, 121, '09/14/2011-23:23:26', NULL, 9);
INSERT INTO `tbl_visits` VALUES (92, 186, '09/15/2011-20:20:24', NULL, 0);
INSERT INTO `tbl_visits` VALUES (93, 78, '09/15/2011-21:21:07', NULL, 9);
INSERT INTO `tbl_visits` VALUES (94, 147, '09/15/2011-23:23:03', NULL, 9);
INSERT INTO `tbl_visits` VALUES (95, 58, '09/16/2011-22:22:16', NULL, 9);
INSERT INTO `tbl_visits` VALUES (96, 167, '09/17/2011-0:00:41', NULL, 9);
INSERT INTO `tbl_visits` VALUES (97, 167, '09/17/2011-0:00:41', NULL, 9);
INSERT INTO `tbl_visits` VALUES (98, 28, '09/17/2011-5:05:12', NULL, 9);
INSERT INTO `tbl_visits` VALUES (99, 61, '09/17/2011-14:14:13', NULL, 9);
INSERT INTO `tbl_visits` VALUES (100, 58, '09/17/2011-17:17:06', NULL, 9);
INSERT INTO `tbl_visits` VALUES (101, 188, '09/17/2011-18:18:10', NULL, 9);
INSERT INTO `tbl_visits` VALUES (102, 41, '09/17/2011-20:20:08', NULL, 9);
INSERT INTO `tbl_visits` VALUES (103, 41, '09/19/2011-13:13:02', NULL, 4);
INSERT INTO `tbl_visits` VALUES (104, 19, '09/19/2011-14:14:34', NULL, 4);
INSERT INTO `tbl_visits` VALUES (105, 149, '09/21/2011-12:12:19', NULL, 5);
INSERT INTO `tbl_visits` VALUES (106, 63, '09/24/2011-5:05:51', NULL, 13);
INSERT INTO `tbl_visits` VALUES (107, 41, '09/28/2011-21:21:17', NULL, 9);
INSERT INTO `tbl_visits` VALUES (108, 68, '09/28/2011-22:22:27', NULL, 9);
INSERT INTO `tbl_visits` VALUES (109, 68, '09/29/2011-22:22:31', NULL, 9);
INSERT INTO `tbl_visits` VALUES (110, 141, '09/30/2011-22:22:38', NULL, 9);
INSERT INTO `tbl_visits` VALUES (111, 61, '10/01/2011-17:17:26', NULL, 9);
INSERT INTO `tbl_visits` VALUES (112, 147, '10/02/2011-19:19:17', NULL, 9);
INSERT INTO `tbl_visits` VALUES (113, 58, '10/02/2011-19:19:00', NULL, 9);
INSERT INTO `tbl_visits` VALUES (114, 179, '10/03/2011-12:12:36', NULL, 5);
INSERT INTO `tbl_visits` VALUES (115, 220, '10/06/2011-10:10:43', NULL, 9);
INSERT INTO `tbl_visits` VALUES (116, 58, '10/08/2011-21:21:01', NULL, 9);
INSERT INTO `tbl_visits` VALUES (117, 224, '10/08/2011-23:23:54', NULL, 9);
INSERT INTO `tbl_visits` VALUES (118, 9, '10/09/2011-14:14:40', NULL, 9);
INSERT INTO `tbl_visits` VALUES (119, 23, '10/09/2011-15:15:08', NULL, 9);
INSERT INTO `tbl_visits` VALUES (120, 252, '10/10/2011-11:11:32', NULL, 13);
INSERT INTO `tbl_visits` VALUES (121, 22, '10/16/2011-18:18:38', NULL, 9);
INSERT INTO `tbl_visits` VALUES (122, 272, '10/22/2011-22:22:39', NULL, 9);
INSERT INTO `tbl_visits` VALUES (123, 28, '10/23/2011-14:14:20', NULL, 9);
INSERT INTO `tbl_visits` VALUES (124, 299, '10/23/2011-14:14:50', NULL, 9);
INSERT INTO `tbl_visits` VALUES (125, 232, '10/23/2011-17:17:01', NULL, 9);
INSERT INTO `tbl_visits` VALUES (126, 117, '10/23/2011-17:17:19', NULL, 9);
INSERT INTO `tbl_visits` VALUES (127, 262, '10/23/2011-18:18:26', NULL, 9);
INSERT INTO `tbl_visits` VALUES (128, 171, '10/24/2011-18:18:49', NULL, 5);
INSERT INTO `tbl_visits` VALUES (129, 149, '10/30/2011-18:18:16', NULL, 9);
INSERT INTO `tbl_visits` VALUES (130, 306, '11/05/2011-1:01:40', NULL, 9);
INSERT INTO `tbl_visits` VALUES (131, 297, '11/05/2011-16:16:42', NULL, 9);
INSERT INTO `tbl_visits` VALUES (132, 61, '11/11/2011-23:23:53', NULL, 9);
INSERT INTO `tbl_visits` VALUES (133, 206, '11/12/2011-18:18:25', NULL, 9);
INSERT INTO `tbl_visits` VALUES (134, 232, '11/13/2011-17:17:06', NULL, 9);
INSERT INTO `tbl_visits` VALUES (135, 280, '11/13/2011-19:19:01', NULL, 9);
INSERT INTO `tbl_visits` VALUES (136, 26, '11/16/2011-22:22:25', NULL, 9);
INSERT INTO `tbl_visits` VALUES (137, 9, '11/23/2011-22:22:08', NULL, 9);
INSERT INTO `tbl_visits` VALUES (138, 206, '11/27/2011-15:15:52', NULL, 9);
INSERT INTO `tbl_visits` VALUES (139, 314, '12/01/2011-21:21:11', NULL, 9);
INSERT INTO `tbl_visits` VALUES (140, 121, '12/01/2011-22:22:31', NULL, 9);
INSERT INTO `tbl_visits` VALUES (141, 141, '12/02/2011-21:21:04', NULL, 9);
INSERT INTO `tbl_visits` VALUES (142, 206, '12/03/2011-16:16:29', NULL, 9);
INSERT INTO `tbl_visits` VALUES (143, 307, '12/03/2011-17:17:00', NULL, 9);
INSERT INTO `tbl_visits` VALUES (144, 17, '12/04/2011-13:13:35', NULL, 9);
INSERT INTO `tbl_visits` VALUES (145, 281, '12/15/2011-22:22:52', NULL, 9);
INSERT INTO `tbl_visits` VALUES (146, 61, '12/16/2011-23:23:12', NULL, 9);
INSERT INTO `tbl_visits` VALUES (147, 263, '12/17/2011-18:18:09', NULL, 9);
INSERT INTO `tbl_visits` VALUES (148, 63, '12/29/2011-6:06:55', NULL, 9);
INSERT INTO `tbl_visits` VALUES (149, 131, '01/04/2012-21:21:11', NULL, 9);
INSERT INTO `tbl_visits` VALUES (150, 320, '01/06/2012-21:21:42', NULL, 9);
INSERT INTO `tbl_visits` VALUES (151, 328, '01/19/2012-22:22:17', NULL, 9);
INSERT INTO `tbl_visits` VALUES (152, 319, '01/27/2012-9:09:55', NULL, 5);
INSERT INTO `tbl_visits` VALUES (153, 186, '03/03/2012-9:09:48', 'Derrick Jones will be staying at #802 for two days vas a geust.', 18);
INSERT INTO `tbl_visits` VALUES (154, 186, '03/03/2012-9:09:00', 'Derrick Jones', 18);
INSERT INTO `tbl_visits` VALUES (155, 315, '05/21/2012-14:14:39', 'not alloed without call', 18);
INSERT INTO `tbl_visits` VALUES (156, 280, '07/08/2012-15:15:06', 'no authorised\r\n', 20);
INSERT INTO `tbl_visits` VALUES (157, 280, '08/06/2012-9:09:42', 'call first!\r\n', 20);
INSERT INTO `tbl_visits` VALUES (158, 356, '07/01/2013-3:03:55', 'The following guests are allowed into the unit. Always call first as usual. If no answer then leave detailed message as to who and when.', 21);
INSERT INTO `tbl_visits` VALUES (159, 360, '07/09/2013-6:06:51', 'Allowed up without', 20);
INSERT INTO `tbl_visits` VALUES (160, 361, '11/15/2013-11:11:51', 'allowed in any time\r\n', 21);
INSERT INTO `tbl_visits` VALUES (161, 361, '02/16/2014-13:13:55', NULL, 20);
INSERT INTO `tbl_visits` VALUES (162, 164, '03/11/2014-20:20:13', NULL, 20);
INSERT INTO `tbl_visits` VALUES (163, 366, '07/12/2014-0:00:37', NULL, 5);
INSERT INTO `tbl_visits` VALUES (164, 366, '07/12/2014-0:00:49', NULL, 27);
